import azure.functions as func
import logging
import json2
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
from datetime import datetime

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

bp = func.Blueprint()

def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip().str.lower()
        return df
    except Exception as e:
        logging.error(f"Error fetching CSV {blob_name}: {e}")
        return None

def calculate_centroid(df, state=None, county=None, tractid=None, year=None):
    required_columns = {'latitude', 'longitude'}
    if not required_columns.issubset(df.columns):
        logging.warning("Missing latitude or longitude columns.")
        return None

    df_filtered = apply_filters(df, state, county, tractid, year)
    
    if df_filtered.empty:
        return None
    
    centroid_lat = df_filtered['latitude'].mean()
    centroid_lon = df_filtered['longitude'].mean()
    
    return [centroid_lat, centroid_lon]

def assign_radius(litter_quantity):
    if litter_quantity <= 10:
        return 6
    elif litter_quantity <= 50:
        return 10
    elif litter_quantity <= 100:
        return 20
    elif litter_quantity <= 500:
        return 25
    else:
        return 30

def format_date(date_str):
    try:
        date_obj = pd.to_datetime(date_str, format="%d-%m-%Y", errors="coerce", dayfirst=True)

        if pd.notna(date_obj):
            return date_obj.strftime("%d %B %Y")
        return "Invalid Date"
    except Exception as e:
        logging.warning(f"Error formatting date {date_str}: {e}")
        return "Invalid Date"

def generate_map_data(df, state=None, county=None, tractid=None, year=None):
    required_columns = {'latitude', 'longitude', 'litter quantity', 'cleanup date'}
    if not required_columns.issubset(df.columns):
        logging.warning("Missing required columns for map data.")
        return []

    df_filtered = apply_filters(df, state, county, tractid, year)
    
    map_data = [
        {
            "date": format_date(row["cleanup date"]),
            "latitude": row["latitude"],
            "longitude": row["longitude"],
            "litter_quantity": row["litter quantity"],
            "radius": assign_radius(row['litter quantity']),
        }
        for _, row in df_filtered.iterrows()
    ]
    
    return map_data

def apply_filters(df, state=None, county=None, tractid=None, year=None):
    df_filtered = df.copy()
    
    if tractid and 'tractid' in df_filtered.columns:
        df_filtered = df_filtered[df_filtered['tractid'].astype(str) == str(tractid)]
    
    if county and ', ' in county:
        city_part, county_part = map(str.strip, county.split(',', 1))
        if 'city' in df_filtered.columns and 'zone' in df_filtered.columns:
            df_filtered = df_filtered[
                (df_filtered['city'].str.lower() == city_part.lower()) &
                (df_filtered['zone'].str.lower() == county_part.lower())
            ]
    elif county and 'zone' in df_filtered.columns:
        df_filtered = df_filtered[df_filtered['zone'].str.lower().str.contains(county.lower(), na=False)]
    
    if state and 'state' in df_filtered.columns:
        df_filtered = df_filtered[df_filtered['state'].str.lower() == state.lower()]
    
    if year and 'cleanup date' in df_filtered.columns:
        df_filtered['year'] = pd.to_datetime(df_filtered['cleanup date'], errors='coerce').dt.year
        df_filtered = df_filtered[df_filtered['year'] == int(year)]
    
    return df_filtered

@bp.function_name('AnalyticsDashboardCityMAPFunction')
@bp.route(route="analyticsdashboardcitymap", methods=["GET"])
def analyticsdashboardcitymap(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for analytics and map data...")

    df_map = fetch_csv_from_blob("CleanSwell_Anlysis_file.csv")
    if df_map is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    state = req.params.get("state")
    county = req.params.get("county")  # Zone is considered as county
    tractid = req.params.get("tractid")
    year = req.params.get("year")

    map_data = generate_map_data(df_map, state, county, tractid, year)
    centroid = calculate_centroid(df_map, state, county, tractid, year)

    response_data = {
        "map_data": map_data,
        "centroid": centroid if centroid else "No location found"
    }

    return func.HttpResponse(json2.dumps(response_data, indent=4), mimetype="application/json", status_code=200)
