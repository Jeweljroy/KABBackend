import azure.functions as func
import logging
import json2
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import numpy as np

# Create a Blueprint for organizing functions
bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip().str.lower()  # Normalize column names
        return df
    except Exception as e:
        logging.error(f"❌ Error fetching CSV {blob_name}: {e}")
        return None

# Assign radius based on litter quantity
def assign_radius(litter_quantity):
    if litter_quantity <= 10:
        return 6
    elif litter_quantity <= 50:
        return 10
    elif litter_quantity <= 100:
        return 20
    elif litter_quantity <= 500:
        return 25
    else:
        return 30

# Function to apply filters
def apply_filters(df, state=None, county=None, year=None, tractid=None):
    try:
        if 'tractid' in df.columns:
            df['tractid'] = pd.to_numeric(df['tractid'], errors='coerce', downcast='integer')
            tractid = int(tractid) if tractid else None

        if 'year' in df.columns:
            df['year'] = pd.to_numeric(df['year'], errors='coerce', downcast='integer')

        filtered_df = df.copy()
        
        if state and 'state' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['state'].str.lower() == state.lower()]
        if county and 'countyid' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['countyid'] == int(county)]
        if year and 'year' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['year'] == int(year)]
        if tractid and 'tractid' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['tractid'] == tractid]
        
        return filtered_df
    except Exception as e:
        logging.error(f"Error applying filters: {e}")
        return df

# Format data for dropdowns (State, County, TractID, Year)
# def format_dropdown_data(df):
#     """Extract unique State, County, TractID, and Year values as JSON."""
#     if df is None:
#         return None

#     try:
#         states = [{"value": state, "label": state} for state in sorted(df['state'].dropna().unique())]
#         counties = [{"value": county, "label": county} for county in sorted(df['zone'].dropna().unique())]
#         tracts = [{"value": str(tract), "label": str(tract)} for tract in sorted(df['tractid'].dropna().unique())]
#         years = [{"value": str(year), "label": str(year)} for year in sorted(df['year'].dropna().unique())]

#         return {
#             "States": states,
#             "Counties": counties,
#             "TractIDs": tracts,
#             "Years": years
#         }

#     except KeyError as e:
#         logging.error(f"❌ Missing column in CSV: {e}")
#         return None


# # Function to get dropdown values
# @bp.function_name('DropdownFunction')
# @bp.route(route="dropdowns", methods=["GET"])
# def get_dropdowns(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("📥 Processing request for dropdowns...")

#     try:
#         BLOB_NAME = "Anlysis_data_final.csv"  # Using Anlysis_data_final.csv for dropdowns
#         df = fetch_csv_from_blob(BLOB_NAME)

#         if df is None:
#             logging.error("❌ Error: Data not fetched from blob.")
#             return func.HttpResponse("Error fetching data", status_code=500)

#         dropdown_data = format_dropdown_data(df)

#         if dropdown_data is None:
#             logging.error("❌ Error: Dropdown data is empty.")
#             return func.HttpResponse("Error generating dropdown data", status_code=500)

#         return func.HttpResponse(
#             json2.dumps(dropdown_data, indent=4),
#             mimetype="application/json",
#             status_code=200
#         )
#     except Exception as e:
#         logging.error(f"❌ Error in dropdowns endpoint: {e}")
#         return func.HttpResponse("Internal Server Error", status_code=500)

# def generate_map_data(df):
#     if not {'latitude', 'longitude', 'litter quantity'}.issubset(df.columns):
#         logging.warning("Missing required columns for map data.")
#         return []
#     return [
#         {
#             "latitude": row['latitude'],
#             "longitude": row['longitude'],
#             "litter_quantity": row['litter quantity'],
#             "radius": assign_radius(row['litter quantity']),
#             "cleanup_date": row.get('cleanup date', None)
#         }
#         for _, row in df.dropna(subset=['latitude', 'longitude', 'litter quantity']).iterrows()
#     ]

# Function to generate analytics
def generate_analytics(df):
    try:
        if df.empty:
            return {"trend_chart": {}, "total_cleanups": 0, "top_3_states": {}, "top_3_counties": {}, "pie_chart": {}}
        analytics = {
            "trend_chart": df.groupby("year")["no. of cleanup"].sum().to_dict() if "year" in df.columns and "no. of cleanup" in df.columns else {},
            "total_cleanups": int(df["no. of cleanup"].sum()) if "no. of cleanup" in df.columns else 0,
            "top_3_states": df.groupby("state")["no. of cleanup"].sum().nlargest(3).to_dict() if "state" in df.columns else {},
            "top_3_counties": df.groupby("zone")["no. of cleanup"].sum().nlargest(3).to_dict() if "zone" in df.columns else {},
            "pie_chart": df[[col for col in ["cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"] if col in df.columns]].sum().to_dict()
        }
        return analytics
    except Exception as e:
        logging.error(f"Error generating analytics: {e}")
        return {}

@bp.function_name('Analytics')
@bp.route(route="analytics", methods=["GET"])
def analytics(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for analytics and map data...")
    
    df_analytics = fetch_csv_from_blob("Anlysis_data_final.csv")
    # df_map = fetch_csv_from_blob("CleanSwell_Anlysis_file.csv")
    
    # if df_analytics is None or df_map is None:
    #     return func.HttpResponse("Error fetching data", status_code=500)
    
    analytics_data = generate_analytics(df_analytics)
    # map_data = generate_map_data(df_map)

    # Get filter parameters from request
    state = req.params.get("state")
    county = req.params.get("county")
    tractid = req.params.get("tractid")

    centroid = fetch_centroid(state, county, tractid)

    response_data = {
        "analytics": analytics_data,
        "centroid": centroid if centroid else "No location found"
    }
    
    return func.HttpResponse(json2.dumps(response_data, indent=4), mimetype="application/json", status_code=200)

def fetch_centroid(state=None, county=None, tractid=None):
    df_centroids = fetch_csv_from_blob("USA_Centroids.csv")
    
    if df_centroids is None:
        return None

    # Normalize column names
    df_centroids.columns = df_centroids.columns.str.strip().str.lower()

    # Ensure the required columns exist
    required_columns = {"latitude", "longitude"}
    if not required_columns.issubset(df_centroids.columns):
        return None  # Missing necessary location data

    # Convert 'tractid' to string for comparison
    if "tractid" in df_centroids.columns:
        df_centroids['tractid'] = df_centroids['tractid'].astype(str)

    # Check in order: TractID -> County -> State
    if tractid and "tractid" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['tractid'] == str(tractid)]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if county and "county" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['county'].str.lower().fillna("") == county.lower()]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if state and "state" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['state'].str.lower().fillna("") == state.lower()]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    return None  # No matching location found
