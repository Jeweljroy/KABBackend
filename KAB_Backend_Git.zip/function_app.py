import logging
import azure.functions as func
import azure.functions as func
from azure.data.tables import TableServiceClient, TableEntity
import bcrypt
import pyotp
import os
import azure.functions as func
from azure.functions import FunctionApp, HttpRequest, HttpResponse
import json
import os
import bcrypt
from email.mime.text import MIMEText
from additional_functions import bp
# from userData import bp
# from dataanalysis import bp
# from dataanalysisKAB import bp

# from userData import bp as user_bp
from userCRED import bp as userCRED_bp
from userProfile import bp as userprofile_bp
from dataanalysis import bp as analysis_bp
from dataanalysisKAB import bp as kab_bp
from dropdownKAB import bp as kabdd_bp
from dropdown import bp as dd_bp
from dataanalysisKABHeatMap import bp as kabheatmap_bp
from dataanalysisWithoutMap import bp as analysiswithoutmap_bp
from dataanalysisExternal import bp as analysisexternal_bp
from dataanalysisExternalMap import bp as analysisexternalmap_bp
from predictionDropdown import bp as predictiondropdown_bp
from dataanalysisExternalwithCity import bp as analysisexternalCity_bp
from dropdownCity import bp as ddcity_bp
from dataanalysisExternalCityMap import bp as analysisexternalcitymap_bp
from dashboardPrediction import bp as dashboardprediction_bp
from predictionEventBased import bp as predictioneventbased_bp
from predictionBinsBased import bp as predictionbinsbased_bp
from predictionAmenitiesBased import bp as predictionamenitiesbased_bp
from predictionAmenitiesBasedOnCategory import bp as predictionAmenitiesBasedOnCategory_bp
from mapPredictionWithToolTip import bp as mapPredictionWithToolTip_bp
from dashboardPredictionUpdated import bp as dashboardPredictionUpdated_bp




# from resend_otp import resend_otp_function
# from protected import protected_function
# from verify_email import verify_email_function
# from reset_password import reset_password_function

app = func.FunctionApp() 

# Registering different blueprints
app.register_blueprint(userCRED_bp)
app.register_blueprint(userprofile_bp)
app.register_blueprint(analysis_bp)
app.register_blueprint(kab_bp)
app.register_blueprint(kabdd_bp) 
app.register_blueprint(dd_bp) 
app.register_blueprint(kabheatmap_bp)
app.register_blueprint(analysiswithoutmap_bp)
app.register_blueprint(analysisexternal_bp)
app.register_blueprint(analysisexternalmap_bp)
app.register_blueprint(predictiondropdown_bp)
app.register_blueprint(analysisexternalCity_bp)
app.register_blueprint(ddcity_bp)
app.register_blueprint(analysisexternalcitymap_bp)
app.register_blueprint(dashboardprediction_bp)
app.register_blueprint(predictioneventbased_bp)
app.register_blueprint(predictionbinsbased_bp)
app.register_blueprint(predictionamenitiesbased_bp)
app.register_blueprint(predictionAmenitiesBasedOnCategory_bp)
app.register_blueprint(mapPredictionWithToolTip_bp)
app.register_blueprint(dashboardPredictionUpdated_bp)



@app.route(route="http_trigger", auth_level=func.AuthLevel.FUNCTION)
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    #logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
   
    
