import azure.functions as func
import logging
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import numpy as np
# Create a Blueprint for organizing functions
bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip().str.lower()  # Normalize column names
        return df
    except Exception as e:
        logging.error(f"❌ Error fetching CSV {blob_name}: {e}")
        return None

# Function to apply filters
def apply_filters(df, state=None, county=None, year=None, tractid=None):
    try:
        print("Initial DataFrame:", df.head())
        print(f"Applying filters - state: {state}, county: {county}, tractid: {tractid}, year: {year}")
        
        # Apply filter for state (if passed in request)
        if state and 'state' in df.columns:
            print(f"Filtering by state: {state.lower()}")
            df = df[df['state'].str.lower() == state.lower()]
            print(f"Filtered by state, remaining rows: {df.shape[0]}")
        
        # Apply filter for county (considering it as zone)
        if county and 'zone' in df.columns:
            print(f"Filtering by zone (county): {county}")
            df = df[df['zone'].str.lower() == county.lower()]
            print(f"Filtered by zone (county), remaining rows: {df.shape[0]}")
        
        # Apply filter for year (if passed in request)
        if year and 'year' in df.columns:
            print(f"Filtering by year: {year}")
            df = df[df['year'] == int(year)]
            print(f"Filtered by year, remaining rows: {df.shape[0]}")
        
        # Apply filter for tractid (if passed in request)
        if tractid and 'tractid' in df.columns:
            print(f"Filtering by tractid: {tractid}")
            df = df[df['tractid'] == int(tractid)]
            print(f"Filtered by tractid, remaining rows: {df.shape[0]}")
        
        print(f"Final filtered DataFrame shape: {df.shape}")
        return df

    except Exception as e:
        print(f"Error applying filters: {e}")
        return df       

import logging
import json as json2

def generate_analytics(dfbeforefilter, df, state=None, year=None, dfcounty=None):
    try:
        logging.info("Starting analytics generation...")

        if df.empty:
            logging.warning("Filtered data is empty. Using the full dataset.")
            df = dfbeforefilter

        if df.empty:
            logging.error("Both filtered and unfiltered datasets are empty.")
            return {}

        df.columns = df.columns.str.strip().str.lower()
        dfbeforefilter.columns = dfbeforefilter.columns.str.strip().str.lower()

        required_columns = {"year", "no. of cleanup"}
        missing_columns = required_columns - set(df.columns)

        if missing_columns:
            logging.error(f"Missing columns: {missing_columns}")
            return {}

        trend_chart = df.groupby("year")["no. of cleanup"].sum().to_dict()
        total_cleanups = int(df["no. of cleanup"].sum())
        top_3_states = generate_top_3_states(dfbeforefilter, year)
        top_3_counties = generate_top_3_counties(dfcounty, state, year)

        # waste_types = {"cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"}
        # pie_chart = {col: df[col].sum() for col in waste_types if col in df.columns}

        # analytics = {
        #     "trend_chart": trend_chart,
        #     "total_cleanups": total_cleanups,
        #     "top_3_states": top_3_states,
        #     "top_3_counties": top_3_counties,
        #     "pie_chart": pie_chart
        # }

        # waste_types = {"cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"}  
        # pie_chart = {col.capitalize(): df[col].sum() for col in waste_types if col in df.columns}  
        waste_types = ["cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"]
        pie_chart = {wt.capitalize(): df[wt].sum() if wt in df.columns else 0 for wt in waste_types}


        analytics = {  
            "trend_chart": trend_chart,  
            "total_cleanups": total_cleanups,  
            "top_3_states": top_3_states,  
            "top_3_counties": top_3_counties,  
            "pie_chart": pie_chart  
        }

        logging.info("Analytics generated successfully.")
        return analytics

    except Exception as e:
        logging.error(f"Error generating analytics: {e}", exc_info=True)
        return {}

def generate_top_3_states(df, year=None):
    try:
        if year:
            df = df[df['year'] == int(year)]

        top_3_states = df.groupby("state")["no. of cleanup"].sum().nlargest(3).to_dict() if "state" in df.columns else {}

        return top_3_states

    except Exception as e:
        logging.error(f"Error generating top_3_states: {e}")
        return {}

def generate_top_3_counties(df, state=None, year=None):
    try:
        if state and year:
            df_filtered = df[(df["state"].str.lower() == state.lower()) & (df["year"] == int(year))]
        elif state:
            df_filtered = df[df["state"].str.lower() == state.lower()]
        elif year:
            df_filtered = df[df["year"] == int(year)]
        else:
            df_filtered = df

        if df_filtered.empty:
            logging.warning(f"No data found for given filters: state={state}, year={year}")
            return {}

        top_3_counties = (
            df_filtered.groupby("zone")["no. of cleanup"].sum().nlargest(3).to_dict()
            if "zone" in df.columns else {}
        )

        return top_3_counties

    except Exception as e:
        logging.error(f"Error generating top_3_counties: {e}")
        return {}

@bp.function_name('AnalyticsDashboardFunction')
@bp.route(route="analyticsdashboard", methods=["GET"])
def analyticsdashboard(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for analytics...")

    df_analytics = fetch_csv_from_blob("Anlysis_data_final.csv")
    if df_analytics is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    df_analytics.columns = df_analytics.columns.str.strip().str.lower()
    df_county = df_analytics.copy()
    
    state = req.params.get("state")
    county = req.params.get("county")
    tractid = req.params.get("tractid")
    year = req.params.get("year")

    df_filtered = apply_filters(df_analytics, state, county, year, tractid)

    analytics_data = generate_analytics(df_analytics, df_filtered, state, year, df_county)
    centroid = fetch_centroid(state, county, tractid)

    response_data = {
        "analytics": analytics_data,
        "centroid": centroid if centroid else "No location found"
    }

    def convert_numpy(obj):
        if isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        raise TypeError(f"Type {type(obj)} not serializable")

    return func.HttpResponse(
        json2.dumps(response_data, indent=4, default=convert_numpy),
        mimetype="application/json",
        status_code=200
    )



def fetch_centroid(state=None, county=None, tractid=None):
    df_centroids = fetch_csv_from_blob("USA_Centroids.csv")
    
    if df_centroids is None:
        return None

    # Normalize column names
    df_centroids.columns = df_centroids.columns.str.strip().str.lower()

    # Ensure the required columns exist
    required_columns = {"latitude", "longitude"}
    if not required_columns.issubset(df_centroids.columns):
        return None  # Missing necessary location data

    # Convert 'tractid' to string for comparison
    if "tractid" in df_centroids.columns:
        df_centroids['tractid'] = df_centroids['tractid'].astype(str)

    # Check in order: TractID -> County -> State
    if tractid and "tractid" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['tractid'] == str(tractid)]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if county and "county" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['county'].str.lower().fillna("") == county.lower()]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if state and "state" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['state'].str.lower().fillna("") == state.lower()]
        if not df_filtered.empty:  # FIXED LINE
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    return None  # No matching location found


