import azure.functions as func
import json
import numpy as np
import geopandas as gpd
import pandas as pd
import io
import logging
import os
from azure.storage.blob import BlobServiceClient
from shapely.geometry import shape
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Environment variables
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_BLOB_CONTAINER")
BLOB_NAME = os.getenv("AZURE_BLOB_NAME")

bp = func.Blueprint()

def fetch_geojson_from_blob():
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=BLOB_NAME)
        blob_data = blob_client.download_blob().readall()
        gdf = gpd.read_file(io.BytesIO(blob_data))
        gdf = gdf.dropna()
        return gdf
    except Exception as e:
        logging.error(f"Error fetching GeoJSON: {e}")
        return None

def format_large_number(value):
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f} M"
    return round(value, 2)

@bp.function_name('DashboardPrediction')
@bp.route(route="dashboardPrediction", methods=["GET"])
def dashboardPrediction(req: func.HttpRequest) -> func.HttpResponse:
    try:
        gdf = fetch_geojson_from_blob()
        if gdf is None:
            return func.HttpResponse("Failed to fetch GeoJSON data", status_code=500)

        state_filter = req.params.get("State")
        county_filter = req.params.get("County")
        tractid_filter = req.params.get("TRACTID")
        week_id_filter = req.params.get("week_id")

        gdf['Litter_density'] = pd.to_numeric(gdf['Litter_density'], errors='coerce')
        gdf['Predicted_Qty'] = pd.to_numeric(gdf['Predicted_Qty'], errors='coerce')
        gdf['Litter_density'].fillna(gdf['Litter_density'].mean(), inplace=True)
        gdf['Predicted_Qty'].fillna(gdf['Predicted_Qty'].mean(), inplace=True)

        if state_filter:
            gdf = gdf[gdf['State'] == state_filter]
        if county_filter:
            gdf = gdf[gdf['County'] == county_filter]
        if tractid_filter:
            gdf = gdf[gdf['TRACTID'] == tractid_filter]
        if week_id_filter:
            gdf = gdf[gdf['week_id'] == int(week_id_filter)]

        if not gdf.empty:
            centroid = gdf.geometry.unary_union.centroid
            centroid_lat, centroid_lon = centroid.y, centroid.x
        else:
            centroid_lat, centroid_lon = None, None

        total_estimated_litter = gdf['Predicted_Qty'].sum()
        estimated_litter_density = gdf['Litter_density'].mean()

        pie_chart = {
            category: round(gdf[category].sum(), 2)
            for category in ["Cigarette", "Glass", "Metal", "Organic", "Other", "Paper", "Plastic", "Rubber"]
        }

        response_data = {
            "centroid": {
                "latitude": centroid_lat,
                "longitude": centroid_lon
            },
            "total": {
                "Total Estimated Litter": format_large_number(total_estimated_litter),
                "Estimated Litter Density": format_large_number(estimated_litter_density),
                "pie_chart": pie_chart
            }
        }

        return func.HttpResponse(json.dumps(response_data), mimetype="application/json", status_code=200)
    except Exception as e:
        logging.error(f"Function error: {str(e)}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
