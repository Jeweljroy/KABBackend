import pandas as pd

df = pd.read_excel("KAB_Roadway_sites.xlsx")
print(df.head())

import openmeteo_requests
import requests_cache
import pandas as pd
import time
from retry_requests import retry
from datetime import datetime
 
# Setup the Open-Meteo API client with cache and retry on error
cache_session = requests_cache.CachedSession(allowable_methods=['GET'], expire_after=-1, backend='memory')
retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
openmeteo = openmeteo_requests.Client(session=retry_session)
 
def get_climate_data(lat, lon, date, url="https://archive-api.open-meteo.com/v1/archive"):
    """Fetch climate data for a given latitude, longitude, and date."""
    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": date,
        "end_date": date,
        "hourly": [
            "cloudcover", "temperature_2m", "relative_humidity_2m", "wind_speed_10m",
            "precipitation", "rain", "showers", "snowfall"
        ],
        "daily": [
            "temperature_2m_max", "temperature_2m_min", "precipitation_sum"
        ],
        "timezone": "auto"
    }
    try:
        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]  # Extract the first response
        time.sleep(0.1)  # Rate limit handling
        return response
    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None
 
def process_weather_data(response):
    """Process the weather response to extract required hourly and daily data."""
    if response is None:
        return None
    hourly = response.Hourly()
    daily = response.Daily()
    avg_values = {
        "avg_cloudcover": sum(hourly.Variables(0).ValuesAsNumpy()) / len(hourly.Variables(0).ValuesAsNumpy()),
        "avg_temperature": sum(hourly.Variables(1).ValuesAsNumpy()) / len(hourly.Variables(1).ValuesAsNumpy()),
        "avg_humidity": sum(hourly.Variables(2).ValuesAsNumpy()) / len(hourly.Variables(2).ValuesAsNumpy()),
        "avg_wind_speed": sum(hourly.Variables(3).ValuesAsNumpy()) / len(hourly.Variables(3).ValuesAsNumpy())
    }
    sum_values = {
        "total_precipitation": sum(hourly.Variables(4).ValuesAsNumpy()),
        "total_rain": sum(hourly.Variables(5).ValuesAsNumpy()),
        "total_showers": sum(hourly.Variables(6).ValuesAsNumpy()),
        "total_snowfall": sum(hourly.Variables(7).ValuesAsNumpy())
    }
    return {**avg_values, **sum_values}
 
def main(df):
    """Main function to process DataFrame and fetch weather data efficiently."""
    # Convert 'Date & time:' to datetime and extract the date
    df["date"] = df["Date and Time:"].apply(lambda x: datetime.strptime(x, "%m/%d/%Y %H:%M").strftime('%Y-%m-%d'))
    results = []
    for _, row in df.iterrows():
        lat, lon = row["y"], row["x"]  # Use provided coordinates instead of centroid
        date = row["date"]
        weather_response = get_climate_data(lat, lon, date)
        processed_data = process_weather_data(weather_response)
        results.append(processed_data)
    weather_df = pd.DataFrame(results)
    return df.join(weather_df)
 
# Usage:
# df = pd.read_csv("your_data.csv")  # Load your DataFrame
result_df = main(df)
# result_df.to_csv("output.csv")  # Save the output if needed