import azure.functions as func
import logging
import json2
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient

# Create a Blueprint
bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
BLOB_NAME = "Anlysis_data_final.csv"

# Fetch CSV data from blob
def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))

        # Normalize columns
        df.columns = df.columns.str.strip().str.lower()
        df.rename(columns={"zone": "county"}, inplace=True)

        return df
    except Exception as e:
        logging.error(f"Error fetching CSV: {e}")
        return None

# Generate dropdown data
def generate_dropdown(df, state=None, county=None, tractid=None, year=None):
    dropdown_data = {"Dropdown": [], "Years": []}

    # Columns
    state_col = "state"
    county_col = "county"
    city_col = "city"
    tractid_col = "tractid"
    year_col = "year"

    # Clean
    df[state_col] = df[state_col].astype(str).str.strip().str.lower()
    df[county_col] = df[county_col].astype(str).str.strip().str.lower()
    df[city_col] = df[city_col].astype(str).str.strip().str.lower()
    df[tractid_col] = df[tractid_col].astype(str).str.strip()
    df[year_col] = df[year_col].astype(str).str.strip()

    # Apply year filter globally
    if year:
        year = year.strip()
        df = df[df[year_col] == year]

    # No params → All unique States + Years
    if not state and not county and not tractid:
        states = sorted(df[state_col].dropna().unique())
        dropdown_data["Dropdown"] = [{"value": s.title(), "label": s.title()} for s in states]
        years = sorted(df[year_col].dropna().unique())
        dropdown_data["Years"] = [{"value": y, "label": y} for y in years]
        return dropdown_data

    # State only → All unique [City, County] in state + filtered Years
    if state and not county and not tractid:
        state = state.strip().lower()
        df = df[df[state_col] == state]

        unique_city_county = df[[city_col, county_col]].drop_duplicates()
        dropdown_data["Dropdown"] = [
            {"value": f"{row[city_col].title()}, {row[county_col].title()}",
             "label": f"{row[city_col].title()}, {row[county_col].title()}"}
            for index, row in unique_city_county.iterrows()
        ]
        years = sorted(df[year_col].dropna().unique())
        dropdown_data["Years"] = [{"value": y, "label": y} for y in years]
        return dropdown_data

    # State + County → All unique TractIDs + filtered Years
    if state and county and not tractid:
        state = state.strip().lower()
        parts = [c.strip().lower() for c in county.split(',')]
        if len(parts) == 2:
            city, county = parts
            df = df[(df[state_col] == state) & (df[city_col] == city) & (df[county_col] == county)]
            tractids = sorted(df[tractid_col].dropna().unique())
            dropdown_data["Dropdown"] = [{"value": t, "label": t} for t in tractids]
            years = sorted(df[year_col].dropna().unique())
            dropdown_data["Years"] = [{"value": y, "label": y} for y in years]
            return dropdown_data

    # State + County + TractID → Years filtered
    if state and county and tractid:
        state = state.strip().lower()
        parts = [c.strip().lower() for c in county.split(',')]
        tractid = tractid.strip()
        if len(parts) == 2:
            city, county = parts
            df = df[
                (df[state_col] == state)
                & (df[city_col] == city)
                & (df[county_col] == county)
                & (df[tractid_col] == tractid)
            ]
            years = sorted(df[year_col].dropna().unique())
            dropdown_data["Years"] = [{"value": y, "label": y} for y in years]
            return dropdown_data

    return dropdown_data  # fallback empty

# Azure Function Route
@bp.function_name("DropdownFunctionWithCityFilter")
@bp.route(route="dropdownswithcityfilter", methods=["GET"])
def get_dropdowns(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for dropdowns...")

    state = req.params.get("state")
    county = req.params.get("county")
    tractid = req.params.get("tractid")
    year = req.params.get("year")

    df = fetch_csv_from_blob(BLOB_NAME)
    if df is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    dropdown_data = generate_dropdown(df, state, county, tractid, year)
    return func.HttpResponse(json2.dumps(dropdown_data, indent=4), mimetype="application/json", status_code=200)
