import azure.functions as func
import json
import logging
import io
import geopandas as gpd
from azure.storage.blob import BlobServiceClient

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
BLOB_NAME = "BINS_PredictionScreen.geojson"

def fetch_geojson_from_blob():
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=BLOB_NAME)
        blob_data = blob_client.download_blob().readall()
        gdf = gpd.read_file(io.BytesIO(blob_data))

        # Drop rows with null values and ensure string types
        gdf = gdf.dropna()
        for col in ['State', 'City', 'TRACTID']:
            gdf[col] = gdf[col].astype(str).str.strip()

        return gdf
    except Exception as e:
        logging.error(f"Error fetching GeoJSON: {e}")
        return None

@bp.function_name('PredictionBinsBased')
@bp.route(route="binsBasedPrediction", methods=["GET"])
def bins_based_prediction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("binsBasedPrediction endpoint called")

    gdf = fetch_geojson_from_blob()
    if gdf is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    # Extract query parameters
    state_filter = req.params.get("State")
    county_filter = req.params.get("County")  # This maps to 'City'
    tractid_filter = req.params.get("TRACTID")
    week_id_filter = req.params.get("week_id")

    logging.info(f"Filters received — State: {state_filter}, County(City): {county_filter}, TRACTID: {tractid_filter}, week_id: {week_id_filter}")

    # Apply filters
    if state_filter:
        gdf = gdf[gdf['State'].str.lower() == state_filter.strip().lower()]
    if county_filter:
        gdf = gdf[gdf['City'].str.lower() == county_filter.strip().lower()]
    if tractid_filter:
        tractid_clean = tractid_filter.strip().zfill(6)  # Pad to 6 digits
        gdf = gdf[gdf['TRACTID'].str.zfill(6) == tractid_clean]
        logging.info(f"Applied TRACTID filter: {tractid_clean}")
    if week_id_filter:
        try:
            gdf = gdf[gdf['week_id'] == int(week_id_filter)]
        except ValueError:
            return func.HttpResponse("Invalid week_id filter", status_code=400)

    logging.info(f"Filtered data size: {len(gdf)} rows")

    # Build response
    bins_data = [
        {
            "latitude": row["latitude"],
            "longitude": row["longitude"]
        }
        for _, row in gdf.iterrows()
    ]

    return func.HttpResponse(json.dumps(bins_data), mimetype="application/json")
