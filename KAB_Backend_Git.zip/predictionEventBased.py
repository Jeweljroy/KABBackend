
import azure.functions as func
import logging
import pandas as pd
import io
import json
from typing import Optional
from azure.storage.blob import BlobServiceClient

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
BLOB_NAME = "Event_Output.csv"


def load_event_data() -> Optional[pd.DataFrame]:
    try:
        # Connect to Blob Storage
        blob_service = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service.get_blob_client(container=CONTAINER_NAME, blob=BLOB_NAME)
        blob_data = blob_client.download_blob().readall()

        # Load CSV using default comma delimiter
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip()

        # Required columns check
        required_columns = [
            "STATEID", "COUNTYID", "GEOID", "week_id", "attendance", "Event count", "State_County",
            "percentile", "Impact", "State", "County", "TRACTID", "latitude", "longitude", "City"
        ]
        if not all(col in df.columns for col in required_columns):
            logging.error(f"Missing required columns. Found: {df.columns.tolist()}")
            return None

        # Clean and normalize for filtering
        df["State"] = df["State"].astype(str).str.strip().str.lower()
        df["City"] = df["City"].astype(str).str.strip().str.lower()
        df["TRACTID"] = df["TRACTID"].astype(str).str.zfill(6)

        return df

    except Exception as e:
        logging.error(f"Error loading data from blob: {e}")
        return None


@bp.function_name(name="EventBasedPrediction")
@bp.route(route="eventBasedPrediction", methods=["GET"])
def event_based_prediction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Received request at /eventBasedPrediction")

    df = load_event_data()
    if df is None:
        return func.HttpResponse(
            json.dumps({"error": "Data loading failed. Required columns may be missing."}),
            status_code=500,
            mimetype="application/json"
        )

    # Get filters from query params
    state_param = req.params.get("State")
    county_param = req.params.get("County")  # Used to filter by City
    tractid_param = req.params.get("TRACTID")
    week_id_param = req.params.get("week_id")

    try:
        if state_param:
            df = df[df["State"] == state_param.strip().lower()]
        if county_param:
            df = df[df["City"] == county_param.strip().lower()]  # Filtering City using County param
        if tractid_param:
            df = df[df["TRACTID"] == tractid_param.strip().zfill(6)]
        if week_id_param:
            df = df[df["week_id"] == int(week_id_param)]
    except Exception as e:
        logging.error(f"Error applying filters: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Invalid filter values."}),
            status_code=400,
            mimetype="application/json"
        )

    try:
        # Columns to return in output
        output_columns = [
            "STATEID", "COUNTYID", "GEOID", "week_id", "attendance", "Event count", "State_County",
            "percentile", "Impact", "State", "County", "TRACTID", "latitude", "longitude", "City"
        ]
        result = df[output_columns].to_dict(orient="records")

        return func.HttpResponse(
            json.dumps({"data": result}),
            status_code=200,
            mimetype="application/json"
        )
    except Exception as e:
        logging.error(f"Error formatting response: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Failed to format output data."}),
            status_code=500,
            mimetype="application/json"
        )
