import azure.functions as func
import json
import logging
import io
import geopandas as gpd
import pandas as pd
import urllib.parse
from azure.storage.blob import BlobServiceClient

bp = func.Blueprint()

# Azure Blob Storage configuration
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
BLOB_NAME = "Amenity_PredictionScreen.geojson"

def load_geojson():
    try:
        blob_service = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service.get_blob_client(container=CONTAINER_NAME, blob=BLOB_NAME)
        data = blob_client.download_blob().readall()
        gdf = gpd.read_file(io.BytesIO(data))

        logging.info(f"GeoJSON loaded: {len(gdf)} rows | Columns: {list(gdf.columns)}")

        # Drop rows missing required fields
        required_cols = ["latitude", "longitude", "type", "Category", "TRACTID"]
        gdf = gdf.dropna(subset=required_cols)

        # Normalize columns for filtering
        for col in ['State', 'City', 'TRACTID', 'Category', 'type']:
            if col in gdf.columns:
                gdf[col] = gdf[col].astype(str).str.strip()

        return gdf
    except Exception as e:
        logging.error(f"Error loading GeoJSON: {e}")
        return None

@bp.function_name('PredictionAmenitiesBasedOnCategory')
@bp.route(route="amenitiesBasedOnCategoryPrediction", methods=["GET"])
def amenities_based_on_category(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Request received: amenitiesBasedOnCategoryPrediction")

    gdf = load_geojson()
    if gdf is None:
        return func.HttpResponse(
            json.dumps({"error": "Failed to load data."}),
            status_code=500,
            mimetype="application/json"
        )

    # Extract & sanitize query parameters
    state = req.params.get("State", "").strip().lower()
    county = req.params.get("County", "").strip().lower()
    tractid = req.params.get("TRACTID", "").strip()
    category = urllib.parse.unquote_plus(req.params.get("Category", "")).strip().lower()
    type_ = urllib.parse.unquote_plus(req.params.get("Type", "")).strip().lower()

    logging.info(f"Filters: State={state}, County={county}, TRACTID={tractid}, Category={category}, Type={type_}")

    # Apply filters one by one
    if category:
        gdf["category_clean"] = gdf["Category"].str.lower().str.strip()
        gdf = gdf[gdf["category_clean"].str.contains(category)]
        logging.info(f"After Category filter: {len(gdf)} rows")

    if type_:
        gdf["type_clean"] = gdf["type"].str.lower().str.strip()
        gdf = gdf[gdf["type_clean"].str.contains(type_)]
        logging.info(f"After Type filter: {len(gdf)} rows")

    if state:
        gdf = gdf[gdf["State"].str.lower().str.strip() == state]
        logging.info(f"After State filter: {len(gdf)} rows")

    if county:
        gdf["city_clean"] = gdf["City"].str.lower().str.replace(",", "").str.replace("  ", " ").str.strip()
        county_clean = county.replace(",", "").replace("  ", " ")
        gdf = gdf[gdf["city_clean"] == county_clean]
        logging.info(f"After County (City) filter: {len(gdf)} rows")

    if tractid:
        tractid_clean = tractid.zfill(6)  # Pad to 6-digit string
        gdf = gdf[gdf["TRACTID"].str.strip() == tractid_clean]
        logging.info(f"After TRACTID filter (padded={tractid_clean}): {len(gdf)} rows")

    # Build response
    amenities = [
        {
            "latitude": row["latitude"],
            "longitude": row["longitude"],
            "type": row["type"],
            "category": row["Category"],
            "tractid": row["TRACTID"]
        }
        for _, row in gdf.iterrows()
    ]

    if not amenities:
        logging.warning("No amenities matched the filters.")
        return func.HttpResponse(
            json.dumps([]),
            status_code=200,
            mimetype="application/json"
        )

    return func.HttpResponse(
        json.dumps(amenities),
        status_code=200,
        mimetype="application/json"
    )
