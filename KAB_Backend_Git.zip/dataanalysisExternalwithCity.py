import azure.functions as func
import logging
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import numpy as np
import json as json2

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip().str.lower()
        return df
    except Exception as e:
        logging.error(f"Error fetching CSV {blob_name}: {e}")
        return None

def apply_filters(df, state=None, county=None, tractid=None, year=None):
    try:
        df.columns = df.columns.str.strip().str.lower()

        # Apply state filter
        if state and "state" in df.columns:
            df = df[df["state"].str.lower() == state.lower()]

        # Apply city and county filter
        if county and "zone" in df.columns and "city" in df.columns:
            # Split county parameter into city and county (City, County format)
            city, county_name = county.split(",") if "," in county else (county, None)
            city, county_name = city.strip(), county_name.strip() if county_name else None

            if city:
                df = df[df["city"].str.lower() == city.lower()]
            if county_name:
                df = df[df["zone"].str.lower() == county_name.lower()]

        # Apply year filter
        if year and "year" in df.columns:
            df = df[df["year"] == int(year)]

        # Apply tractid filter (ensure tractid is treated as a string for filtering)
        if tractid and "tractid" in df.columns:
            df["tractid"] = df["tractid"].astype(str)  # Ensure tractid is treated as string
            df = df[df["tractid"] == str(tractid)]  # Compare with the provided tractid

        return df
    except Exception as e:
        logging.error(f"Error applying filters: {e}")
        return df


def fetch_centroid(state=None, county=None, tractid=None):
    try:
        # Fetch centroids data
        df_centroids = fetch_csv_from_blob("USA_Centroids.csv")
        
        if df_centroids is None:
            return None

        df_centroids.columns = df_centroids.columns.str.strip().str.lower()

        # Convert tractid to string for matching
        if "tractid" in df_centroids.columns:
            df_centroids['tractid'] = df_centroids['tractid'].astype(str)

        # Apply tractid filter
        if tractid and "tractid" in df_centroids.columns:
            df_filtered = df_centroids[df_centroids['tractid'] == str(tractid)]
            if not df_filtered.empty:
                return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

        # Apply county filter
        if county and "county" in df_centroids.columns:
            df_filtered = df_centroids[df_centroids['county'].str.lower().fillna("") == county.lower()]
            if not df_filtered.empty:
                return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

        # Apply state filter
        if state and "state" in df_centroids.columns:
            df_filtered = df_centroids[df_centroids['state'].str.lower().fillna("") == state.lower()]
            if not df_filtered.empty:
                return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

        return None  # Return None if no matching centroid found
    except Exception as e:
        logging.error(f"Error fetching centroid: {e}")
        return None

def generate_analytics(dfbeforefilter, df, state=None, county=None, tractid=None, year=None):
    try:
        logging.info("Starting analytics generation...")

        # If the filtered data is empty, fall back to unfiltered data
        if df.empty:
            logging.warning("Filtered data is empty. Using full dataset.")
            df = dfbeforefilter

        if df.empty:
            logging.error("Both filtered and unfiltered datasets are empty.")
            return {}

        df.columns = df.columns.str.strip().str.lower()
        dfbeforefilter.columns = dfbeforefilter.columns.str.strip().str.lower()

        # Generate Trend Chart (filtered data)
        trend_chart = df.groupby("year")["no. of cleanup"].sum().to_dict() if "year" in df.columns else {}

        # Generate Total Cleanups (filtered data)
        total_cleanups = int(df["no. of cleanup"].sum()) if "no. of cleanup" in df.columns else 0

        # Filter dfbeforefilter by year for top 3 states and counties
        df_top = dfbeforefilter.copy()
        if year and "year" in df_top.columns:
            df_top = df_top[df_top["year"] == int(year)]

        # Top 3 States (Filtered by year)
        top_3_states = (
            df_top.groupby("state")["no. of cleanup"].sum().nlargest(3).to_dict()
            if "state" in df_top.columns else {}
        )

        # Top 3 Counties (Filtered by state and year)
        top_3_counties = {}
        if state and "state" in df_top.columns:
            df_state = df_top[df_top["state"].str.lower() == state.lower()]
            top_cities = df_state.groupby("city")["no. of cleanup"].sum().nlargest(3)
            top_3_counties = {
                f"{city}, {df_state[df_state['city'] == city]['zone'].iloc[0]}": count
                for city, count in top_cities.items()
            } if not top_cities.empty else {}

        # Pie Chart data (filtered)
        waste_types = ["cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"]
        pie_chart = {wt.capitalize(): df[wt].sum() if wt in df.columns else 0 for wt in waste_types}

        # Get centroid based on filters
        centroid = fetch_centroid(state, county, tractid)

        analytics = {
            "trend_chart": trend_chart,
            "total_cleanups": total_cleanups,
            "top_3_states": top_3_states,
            "top_3_counties": top_3_counties,
            "pie_chart": pie_chart,
            "centroid": centroid
        }

        logging.info("Analytics generated successfully.")
        return analytics

    except Exception as e:
        logging.error(f"Error generating analytics: {e}", exc_info=True)
        return {}


@bp.function_name('AnalyticsDashboardCityFunction')
@bp.route(route="analyticsdashboardcity", methods=["GET"])
def analyticsdashboardcity(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for analytics...")

    # Fetch the main dataset
    df_analytics = fetch_csv_from_blob("Anlysis_data_final.csv")
    if df_analytics is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    df_analytics.columns = df_analytics.columns.str.strip().str.lower()

    # Get filter parameters from the request
    state = req.params.get("state")
    county = req.params.get("county")
    tractid = req.params.get("tractid")
    year = req.params.get("year")

    # Apply filters to the data
    df_filtered = apply_filters(df_analytics, state, county, tractid, year)

    # Generate analytics based on filtered data
    analytics_data = generate_analytics(df_analytics, df_filtered, state, county, tractid, year)

    # Create the response
    response_data = {
        "analytics": analytics_data
    }

    return func.HttpResponse(
        json2.dumps(response_data, indent=4, default=lambda obj: obj.item() if isinstance(obj, (np.integer, np.floating)) else obj),
        mimetype="application/json",
        status_code=200
    )
