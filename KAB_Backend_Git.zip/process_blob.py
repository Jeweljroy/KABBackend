import logging
import json
import os
import pyodbc  # SQL Server Connection
import azure.functions as func

# Database Connection Config (SQL Server Express)
DB_CONFIG = {
    "server": os.getenv("DB_SERVER", "localhost\\SQLEXPRESS"),  # Default local instance
    "database": os.getenv("DB_NAME", "UserDatabase"),
    "username": os.getenv("DB_USER", "sa"),  # Change to your SQL Server user
    "password": os.getenv("DB_PASSWORD", "yourStrongPassword"),
    "driver": "{ODBC Driver 17 for SQL Server}"
}

# Function to Connect to SQL Server Express
def connect_db():
    conn_str = f"DRIVER={DB_CONFIG['driver']};SERVER={DB_CONFIG['server']};DATABASE={DB_CONFIG['database']};UID={DB_CONFIG['username']};PWD={DB_CONFIG['password']}"
    return pyodbc.connect(conn_str)

def main(myblob: func.InputStream):
    logging.info(f"Processing blob: {myblob.name}")

    try:
        # Read JSON data from the uploaded blob file
        data = json.loads(myblob.read().decode('utf-8'))

        conn = connect_db()
        cursor = conn.cursor()

        for username, user in data.items():
            email = user["email"]
            password_hash = user["password"]
            role = user["role"]
            is_verified = user["isVerified"]

            # Check if user already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE email = ?", (email,))
            if cursor.fetchone()[0] == 0:
                # Insert new user
                cursor.execute(
                    "INSERT INTO users (username, email, password_hash, role, is_verified) VALUES (?, ?, ?, ?, ?)",
                    (username, email, password_hash, role, is_verified)
                )
                conn.commit()

        cursor.close()
        conn.close()
        logging.info("User data inserted successfully.")

    except Exception as e:
        logging.error(f"Error processing blob: {str(e)}")
