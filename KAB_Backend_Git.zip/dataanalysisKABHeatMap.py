
import azure.functions as func
import logging
import pandas as pd
import json
from azure.storage.blob import BlobServiceClient
import io
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

bp = func.Blueprint()

# Blob file names
KAB_GPS_FILE = "KAB_GPS_data.csv"
KAB_DASHBOARD_FILE = "KAB_dashboard_data.csv"

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)

def fetch_csv_from_blob(file_name):
    """Fetch CSV file from Azure Blob Storage and return as DataFrame."""
    try:
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)
        stream = blob_client.download_blob().readall()
        return pd.read_csv(io.StringIO(stream.decode('utf-8')))
    except Exception as e:
        logging.error(f"Error fetching {file_name}: {str(e)}")
        return None

def calculate_percent_rank(series):
    """Calculate the percentile rank of a given series."""
    return series.rank(pct=True)

def format_litter_quantity(value):
    """Format litter quantity to millions (e.g., 565672267 -> 56.5M)."""
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    return str(value)

@bp.function_name('AnalyticsHeatMap')
@bp.route(route="analytics-heatmap", methods=["GET"])
def analytics_and_heatmap(req: func.HttpRequest) -> func.HttpResponse:
    try:
        state_filter = req.params.get('state')  # Get state from request

        # Fetch CSVs
        gps_df = fetch_csv_from_blob(KAB_GPS_FILE)
        dashboard_df = fetch_csv_from_blob(KAB_DASHBOARD_FILE)

        if gps_df is None or dashboard_df is None:
            return func.HttpResponse("Error fetching data from Blob Storage", status_code=500)

        # Select required columns
        gps_df = gps_df[['State', 'Bottle Bill:', 'Longitude', 'Latitude']]
        dashboard_df = dashboard_df[['State', 'Estimated', 'Litter density']]

        # Merge DataFrames on 'State'
        merged_df = pd.merge(gps_df, dashboard_df, on='State', how='inner')

        # Rename columns for consistency
        merged_df.rename(columns={'Bottle Bill:': 'Bottle Bill Status', 'Estimated': 'Estimated Litter Quantity', 'Litter density': 'Estimated Litter Density'}, inplace=True)

        # Calculate percent rank value for all states
        merged_df['value'] = calculate_percent_rank(merged_df['Estimated Litter Density']).astype(str)

        # Format the 'Estimated Litter Density' to two decimals
        merged_df['Estimated Litter Density'] = merged_df['Estimated Litter Density'].round(2)

        # Format 'Estimated Litter Quantity' to millions if applicable
        merged_df['Estimated Litter Quantity'] = merged_df['Estimated Litter Quantity'].apply(format_litter_quantity)

        # Filter by state if provided
        if state_filter:
            merged_df = merged_df[merged_df['State'].str.lower() == state_filter.lower()]

        # Format response
        response = {
            row['State']: {
                "value": row['value'],
                "State": row['State'],
                "Bottle Bill Status": row['Bottle Bill Status'],
                "Estimated Litter Quantity": row['Estimated Litter Quantity'],
                "Estimated Litter Density": row['Estimated Litter Density']
            }
            for _, row in merged_df.iterrows()
        }

        return func.HttpResponse(json.dumps(response), mimetype="application/json")
    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        return func.HttpResponse("Internal Server Error", status_code=500)
