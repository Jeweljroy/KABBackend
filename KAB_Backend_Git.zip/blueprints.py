import azure.functions as func

bp = func.Blueprint()

@bp.function_name("UserDataFunction")
@bp.route(route="user-data", methods=["GET"])
def user_data(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse("User data API", status_code=200)

@bp.function_name("DataAnalysisFunction")
@bp.route(route="data-analysis", methods=["GET"])
def data_analysis(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse("Data analysis API", status_code=200)
