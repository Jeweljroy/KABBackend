
import azure.functions as func
import logging
import json
import pandas as pd
import io
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

def get_current_week_id():
    return datetime.utcnow().isocalendar().week

def get_weeks_info():
    current_date = datetime.utcnow()
    blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
    container_client = blob_service_client.get_container_client(CONTAINER_NAME)

    weeks = []
    for i in range(4):
        week_date = current_date + timedelta(weeks=i)
        monday = week_date - timedelta(days=week_date.weekday())
        week_id = int(monday.strftime('%V'))
        blob_name = f"Prediction_Output_wk{week_id}.csv"

        # Check if blob exists
        blob_client = container_client.get_blob_client(blob_name)
        blob_exists = blob_client.exists()

        weeks.append({
            "week_id": week_id,
            "week": f"Week of {monday.strftime('%d %B')}",
            "status": "enable" if blob_exists else "disable"
        })

    return weeks

def fetch_csv_from_blob(week_id):
    try:
        blob_name = f"Prediction_Output_wk{week_id}.csv"
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data), dtype={"TRACTID": str})
        df.columns = df.columns.str.strip().str.lower()
        return df
    except Exception as e:
        logging.error(f"Error fetching CSV for week {week_id}: {e}")
        return None

def generate_dropdown(df, state=None, county=None, tractid=None):
    dropdown_data = {"Dropdown": [], "Weeks": get_weeks_info()}

    df["state"] = df["state"].str.strip().str.lower()
    city_col = "city" if "city" in df.columns else None
    tractid_col = "tractid" if "tractid" in df.columns else None

    if city_col:
        df[city_col] = df[city_col].str.strip().str.lower()
    if tractid_col:
        df[tractid_col] = df[tractid_col].astype(str).str.strip().str.lower()

    filtered_df = df.copy()

    if state and state.lower() != "all states":
        filtered_df = filtered_df[filtered_df["state"] == state.lower().split(',')[0]]

    if county and city_col:
        filtered_df = filtered_df[filtered_df[city_col] == county.lower()]

    if tractid and tractid_col:
        filtered_df = filtered_df[filtered_df[tractid_col] == str(tractid).lower()]

    if county and tractid_col:
        dropdown_data["Dropdown"] = [
            {"value": tract, "label": tract} for tract in sorted(filtered_df[tractid_col].dropna().unique())
        ]
    elif state and city_col and state.lower() != "all states":
        dropdown_data["Dropdown"] = [
            {"value": city_val.title(), "label": city_val.title()}
            for city_val in sorted(filtered_df[city_col].dropna().unique())
        ]
    else:
        dropdown_data["Dropdown"] = [
            {"value": state_val.title(), "label": state_val.title()}
            for state_val in sorted(df["state"].dropna().unique())
        ]

    return dropdown_data

@bp.function_name("PredictionDropdownFunctionWithFilter")
@bp.route(route="predictiondropdownswithfilter", methods=["GET"])
def get_predictiondropdowns(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing prediction dropdown request...")

    week_id_param = req.params.get("week_id")
    week_id = int(week_id_param) if week_id_param and week_id_param.isdigit() else get_current_week_id()

    state = req.params.get("state")
    county = req.params.get("county")  # Query param is named "county"
    tractid = req.params.get("tract")

    df = fetch_csv_from_blob(week_id)
    if df is None or df.empty:
        return func.HttpResponse(f"CSV data for week {week_id} not found or empty.", status_code=404)

    dropdown_data = generate_dropdown(df, state, county, tractid)
    return func.HttpResponse(json.dumps(dropdown_data, indent=4), mimetype="application/json", status_code=200)
