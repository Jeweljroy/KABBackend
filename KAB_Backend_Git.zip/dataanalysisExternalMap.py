import azure.functions as func
import logging
import json2
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import numpy as np
from datetime import datetime

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

bp = func.Blueprint()

def fetch_csv_from_blob(blob_name: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        df = pd.read_csv(io.BytesIO(blob_data))
        df.columns = df.columns.str.strip().str.lower()  # Normalize column names
        return df
    except Exception as e:
        logging.error(f"❌ Error fetching CSV {blob_name}: {e}")
        return None

# Assign radius based on litter quantity
def assign_radius(litter_quantity):
    if litter_quantity <= 10:
        return 6
    elif litter_quantity <= 50:
        return 10
    elif litter_quantity <= 100:
        return 20
    elif litter_quantity <= 500:
        return 25
    else:
        return 30

# def generate_map_data(df, state=None, zone=None, year=None):
#     if not {'latitude', 'longitude', 'litter quantity'}.issubset(df.columns):
#         logging.warning("Missing required columns for map data.")
#         return []

#     # Apply filters to the map data
#     df_filtered = apply_filters(df, state, zone, year)

#     # Generate map data after filtering
#     map_data = [
#         {
#             "latitude": row['latitude'],
#             "longitude": row['longitude'],
#             "litter_quantity": row['litter quantity'],
#             "radius": assign_radius(row['litter quantity']),
#             "cleanup_date": row.get('cleanup date', None)
#         }
#         for _, row in df_filtered.dropna(subset=['latitude', 'longitude', 'litter quantity']).iterrows()
#     ]
    
#     return map_data


def parse_date(date_value):
    """Ensure the date is always a string before parsing."""
    if isinstance(date_value, pd.Timestamp):  
        return date_value  # Already a datetime object, return it as is

    if isinstance(date_value, str):
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d %B %Y"):  # Add more formats if needed
            try:
                return datetime.strptime(date_value, fmt)
            except ValueError:
                continue

    return None  # Return None if parsing fails

def generate_map_data(df, state=None, zone=None, year=None, tractid=None):
    if not {'latitude', 'longitude', 'litter quantity'}.issubset(df.columns):
        logging.warning("Missing required columns for map data.")
        return []

    # Apply filters to the map data
    df_filtered = apply_filters(df, state, zone, year, tractid)

    # Generate map data after filtering
    map_data = [
        {
            "date": row["cleanup date"].strftime("%d %B %Y") if pd.notna(row["cleanup date"]) else "Invalid Date",
            "latitude": row["latitude"],
            "longitude": row["longitude"],
            "litter_quantity": row["litter quantity"],
            "radius": assign_radius(row['litter quantity']),
        }
        for _, row in df_filtered.iterrows()
    ]

    return map_data


# Function to apply filters
def apply_filters(df, state=None, zone=None, year=None, tractid=None):
    try:
        print(f"Initial DataFrame shape: {df.shape}")
        print(f"Columns: {df.columns}")

        print(f"Applying filters - state: {state}, zone: {zone}, year: {year}, tractid: {tractid}")

        # Normalize column names (strip spaces and convert to lowercase)
        df.columns = df.columns.str.strip().str.lower()

        # Convert 'tractid' to string for comparison
        if 'tractid' in df.columns:
            df['tractid'] = df['tractid'].astype(str)

        # Convert 'cleanup date' to datetime and extract the year
        if 'cleanup date' in df.columns:
            df['cleanup date'] = pd.to_datetime(df['cleanup date'], format="%d-%m-%Y", dayfirst=True, errors='coerce')  # Handle invalid dates
            df['year'] = df['cleanup date'].dt.year  # Extract year as an integer
            print("Extracted 'year' column:", df['year'].unique())  # Debugging step

        # Apply TractID filter first
        if tractid and 'tractid' in df.columns:
            df = df[df['tractid'] == str(tractid)]
            print(f"Data shape after filtering by tractid: {df.shape}")

        # Apply State filter
        if state and 'state' in df.columns:
            df = df[df['state'].str.lower() == state.lower()]
            print(f"Data shape after filtering by state: {df.shape}")

        # Apply Zone filter
        if zone and 'zone' in df.columns:
            df['zone'] = df['zone'].str.strip().str.lower()
            df = df[df['zone'] == zone.lower()]
            print(f"Data shape after filtering by zone: {df.shape}")

        # Apply Year filter
        if year:
            try:
                year = int(year)  # Ensure year is an integer
                if 'year' in df.columns:
                    df = df[df['year'] == year]
                    print(f"Data shape after filtering by year {year}: {df.shape}")
            except ValueError:
                print(f"Invalid year format: {year}")

        print(f"Final filtered DataFrame shape: {df.shape}")
        return df

    except Exception as e:
        print(f"❌ Error applying filters: {e}")
        return df


def fetch_centroid(state=None, zone=None, tractid=None):
    df_centroids = fetch_csv_from_blob("USA_Centroids.csv")
    
    if df_centroids is None:
        return None

    # Normalize column names
    df_centroids.columns = df_centroids.columns.str.strip().str.lower()

    # Ensure the required columns exist
    required_columns = {"latitude", "longitude"}
    if not required_columns.issubset(df_centroids.columns):
        return None  # Missing necessary location data

    # Convert 'tractid' to string for comparison
    if "tractid" in df_centroids.columns:
        df_centroids['tractid'] = df_centroids['tractid'].astype(str)

    # Check in order: TractID -> Zone -> State
    if tractid and "tractid" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['tractid'] == str(tractid)]
        if not df_filtered.empty:
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if zone and "zone" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['zone'].str.lower().fillna("") == zone.lower()]
        if not df_filtered.empty:
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    if state and "state" in df_centroids.columns:
        df_filtered = df_centroids[df_centroids['state'].str.lower().fillna("") == state.lower()]
        if not df_filtered.empty:
            return [df_filtered.iloc[0]['latitude'], df_filtered.iloc[0]['longitude']]

    return None  # No matching location found

@bp.function_name('AnalyticsDashboardMAPFunction')
@bp.route(route="analyticsdashboardmap", methods=["GET"])
def analyticsdashboardmap(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request for analytics and map data...")

    # Fetch map data
    df_map = fetch_csv_from_blob("CleanSwell_Anlysis_file.csv")
    
    if df_map is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    # Get filter parameters from request
    state = req.params.get("state")
    zone = req.params.get("zone")  # Using 'zone' instead of 'county'
    year = req.params.get("year")
    tractid = req.params.get("tractid")  # Get tractid

    # Generate map data based on filters
    map_data = generate_map_data(df_map, state, zone, year, tractid)

    # Get centroid location data
    centroid = fetch_centroid(state, zone, tractid)

    response_data = {
        "map_data": map_data,
        "centroid": centroid if centroid else "No location found"
    }

    return func.HttpResponse(json2.dumps(response_data, indent=4), mimetype="application/json", status_code=200)

