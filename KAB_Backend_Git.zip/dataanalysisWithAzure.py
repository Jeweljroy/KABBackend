
#############################################################################################################################################

import azure.functions as func
import logging
import json
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import numpy as np

# # Create a Blueprint for organizing functions
bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

# Function to fetch CSV data from blob storage
def fetch_csv_from_blob(blob_name: str):
    """Fetch CSV file from Azure Blob Storage and return as a Pandas DataFrame."""
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)

        # Download blob content
        blob_data = blob_client.download_blob().readall()

        # Read CSV into Pandas DataFrame
        df = pd.read_csv(io.BytesIO(blob_data))

        # Normalize column names: Remove spaces and convert to lowercase
        df.columns = df.columns.str.strip().str.lower()

        logging.info(f"✅ CSV Columns (normalized): {list(df.columns)}")
        return df

    except Exception as e:
        logging.error(f"❌ Error fetching CSV: {e}")
        return None

# Apply filters to the dataframe
def apply_filters(df, state=None, county=None, year=None, tractid=None):
    """Apply filters to the DataFrame."""
    try:
        # Convert 'cleanup date' to datetime if it's not already
        if 'cleanup date' in df.columns:
            df['cleanup date'] = pd.to_datetime(df['cleanup date'], errors='coerce')

        # Filter by 'state' if provided
        if state:
            df = df[df['state'].str.lower() == state.lower()]

        # Filter by 'county' (or 'zone' if 'county' doesn't exist)
        if county:
            if "county" in df.columns:
                df = df[df['county'].str.lower() == county.lower()]
            elif "zone" in df.columns:
                df = df[df['zone'].str.lower() == county.lower()]

        # Filter by 'year' if provided
        if year:
            if 'year' in df.columns:
                df = df[df['year'] == int(year)]

        # Filter by 'tractid' if provided
        if tractid:
            if 'tractid' in df.columns:
                df = df[df['tractid'] == int(tractid)]

        return df

    except Exception as e:
        logging.error(f"❌ Error applying filters: {e}")
        return None


def format_dropdown_data(df):
    """Extract unique State, County, TractID, and Year values as JSON."""
    if df is None:
        return None

    try:
        # Extract unique values
        states = [{"value": state, "label": state} for state in sorted(df['state'].dropna().unique())]
        counties = [{"value": county, "label": county} for county in sorted(df['zone'].dropna().unique())]
        tracts = [{"value": str(tract), "label": str(tract)} for tract in sorted(df['tractid'].dropna().unique())]
        years = [{"value": str(year), "label": str(year)} for year in sorted(df['year'].dropna().unique())]

        # JSON Response
        return {
            "States": states,
            "Counties": counties,
            "TractIDs": tracts,
            "Years": years
        }

    except KeyError as e:
        logging.error(f"❌ Missing column in CSV: {e}")
        return None


# Generate map data for plotting based on filtered data
def generate_map_data(df):
    """Generate map data based on the filtered DataFrame for Latitude, Longitude, Litter Quantity, and Cleanup Year."""
    map_data = []

    try:
        # Extract necessary columns for map data
        if 'latitude' in df.columns and 'longitude' in df.columns and 'no. of cleanup' in df.columns:
            # Ensure we take only the year (YYYY) for the cleanup date
            df['year'] = pd.to_datetime(df['cleanup_date']).dt.year
            for index, row in df.iterrows():
                map_data.append({
                    "latitude": row['latitude'],
                    "longitude": row['longitude'],
                    "litter_quantity": row['no. of cleanup'],
                    "cleanup_year": row['year']
                })
        return map_data
    except KeyError as e:
        logging.error(f"❌ Missing column in CSV: {e}")
        return []

# Generate analytics data from the Anlysis_data_final.csv
def generate_analytics(df):
    """Generate analytics based on the filtered DataFrame."""
    analytics = {}

    try:
        # 1. Trend Chart (Yearly Sum of Cleanups)
        analytics["trend_chart"] = df.groupby("year")["no. of cleanup"].sum().to_dict()

        # 2. Total Cleanup Count
        analytics["total_cleanups"] = int(df["no. of cleanup"].sum())

        # 3. Top 3 States
        analytics["top_3_states"] = {k: int(v) for k, v in df.groupby("state")["no. of cleanup"].sum().nlargest(3).to_dict().items()}

        # 4. Top 3 Counties (use "zone" instead of "county" if needed)
        county_column = "zone"  # Change to "county" if you confirm it's correct
        if county_column in df.columns:
            analytics["top_3_counties"] = {k: int(v) for k, v in df.groupby(county_column)["no. of cleanup"].sum().nlargest(3).to_dict().items()}
        else:
            analytics["top_3_counties"] = {}

        # 5. Pie Chart (Litter Categories Sum)
        litter_columns = ["cigarette", "glass", "metal", "organic", "other", "paper", "plastic", "rubber"]
        analytics["pie_chart"] = {k: int(v) for k, v in df[litter_columns].sum().to_dict().items()}

    except Exception as e:
        logging.error(f"❌ Error generating analytics: {e}")
        return None

    return analytics

# Function to get dropdown values
@bp.function_name('DropdownFunction')
@bp.route(route="dropdowns", methods=["GET"])
def get_dropdowns(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("📥 Processing request for dropdowns...")

    try:
        BLOB_NAME = "Anlysis_data_final.csv"  # Using Anlysis_data_final.csv for dropdowns
        df = fetch_csv_from_blob(BLOB_NAME)

        if df is None:
            logging.error("❌ Error: Data not fetched from blob.")
            return func.HttpResponse("Error fetching data", status_code=500)

        dropdown_data = format_dropdown_data(df)

        if dropdown_data is None:
            logging.error("❌ Error: Dropdown data is empty.")
            return func.HttpResponse("Error generating dropdown data", status_code=500)

        return func.HttpResponse(
            json.dumps(dropdown_data, indent=4),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"❌ Error in dropdowns endpoint: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)

# Function to get analytics and map data
@bp.function_name('AnalyticsAndMapFunction')
@bp.route(route="analytics-map", methods=["GET"])
def analytics_and_map(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing analytics and map data request...")

    try:
        # Fetch data for analytics from Anlysis_data_final.csv
        BLOB_NAME_ANALYTICS = "Anlysis_data_final.csv"  # For Analytics
        df_analytics = fetch_csv_from_blob(BLOB_NAME_ANALYTICS)

        # Fetch data for map from CleanSwell_anlysis.csv
        BLOB_NAME_MAP = "CleanSwell_anlysis.csv"  # For Map Data
        df_map = fetch_csv_from_blob(BLOB_NAME_MAP)

        if df_analytics is None or df_map is None:
            logging.error("❌ Error: Failed to fetch data from blobs.")
            return func.HttpResponse("Error fetching data", status_code=500)

        # Get filter parameters
        state = req.params.get("state")
        county = req.params.get("county")
        year = req.params.get("year")
        tractid = req.params.get("tractid")

        # Apply filters to both analytics and map data
        df_analytics_filtered = apply_filters(df_analytics, state, county, year, tractid)
        df_map_filtered = apply_filters(df_map, state, county, year, tractid)

        if df_analytics_filtered is None or df_map_filtered is None:
            logging.error("❌ Error: Failed to apply filters to data.")
            return func.HttpResponse("Error applying filters", status_code=400)

        # Generate analytics from Anlysis_data_final.csv
        analytics_data = generate_analytics(df_analytics_filtered)

        if analytics_data is None:
            logging.error("❌ Error: Failed to generate analytics.")
            return func.HttpResponse("Error generating analytics", status_code=500)

        # Generate map data from CleanSwell_anlysis.csv
        map_data = generate_map_data(df_map_filtered)

        response_data = {
            "analytics": analytics_data,
            "map_data": map_data
        }

        return func.HttpResponse(
            json.dumps(response_data, default=lambda x: int(x) if isinstance(x, np.integer) else x),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"❌ Error in analytics-map endpoint: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)
    
# ===========================================================================================================

# import logging
# import azure.functions as func
# import pandas as pd
# import io
# import json2
# from azure.storage.blob import BlobServiceClient


# bp = func.Blueprint()


# # Azure Blob Storage Configuration
# CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=lees1ddoaistg01;AccountKey=csSA5kaTMu6dBLkn4fbV7Uj8REa9sPUyvQmG9lShU45Na1O9JCYP3/OibP9CdD0sOaeUr1Bs5J/d+AStb5IFMg==;EndpointSuffix=core.windows.net"
# CONTAINER_NAME = "dataanalysis"

# blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)

# def get_blob_data(blob_name):
#     blob_client = blob_service_client.get_blob_client(CONTAINER_NAME, blob_name)
#     stream = io.BytesIO(blob_client.download_blob().readall())
#     return pd.read_csv(stream)

# def get_excel_data(blob_name):
#     blob_client = blob_service_client.get_blob_client(CONTAINER_NAME, blob_name)
#     stream = io.BytesIO(blob_client.download_blob().readall())
#     return pd.read_excel(stream, engine='openpyxl')

# # Function to get analytics and map data
# @bp.function_name('AnalyticsAndMapKABFunction')
# @bp.route(route="analytics-mapkab", methods=["GET"])
# def analytics_and_mapkab(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("Processing request")
    
#     state = req.params.get('state')
#     y_axis = req.params.get('y_axis')
    
#     try:
#         # Load data from Azure Blob Storage
#         dashboard_data = get_blob_data("KAB_dashboard_data.csv")
#         correlation_data = get_excel_data("Correlation data.xlsx")
#         # gps_data = get_blob_data("KAB_GPS_data.csv")
#         # gps_data = get_blob_data("KAB_GPS_data.csv")
#         # gps_data.columns = gps_data.columns.str.strip()
#         # logging.info(f"GPS Data Columns: {gps_data.columns}")  # Debugging line

#         gps_data = get_blob_data("KAB_GPS_data.csv")
#         gps_data.columns = gps_data.columns.str.strip()  # Fix inconsistent column names

#         # response_data['gps_data'] = gps_data[['Latitude', 'Longitude', 'All Item Type', 'Date and Time:']].to_dict(orient='records')


        
#         response_data = {}
        
#         # Filter data by state
#         if state:
#             dashboard_data = dashboard_data[dashboard_data['State'] == state]
#             gps_data = gps_data[gps_data['State'] == state]
        
#         # Total Estimated Litter
#         response_data['total_estimated_litter'] = dashboard_data['Estimated'].sum()
        
#         # Estimated Litter Density (average)
#         response_data['estimated_litter_density'] = dashboard_data['Litter density'].mean()
        
#         # Top 3 states based on total litter & litter density
#         top_states = dashboard_data.groupby('State').agg({'Estimated': 'sum', 'Litter density': 'mean'})
#         response_data['top_3_states'] = top_states.nlargest(3, 'Estimated').reset_index().to_dict(orient='records')
        
#         # Pie chart data
#         litter_columns = ['Rubber', 'Glass', 'Plastic', 'Cigarette Butts', 'Paper', 'Metal', 'Other', 'Organic']
#         response_data['litter_pie_chart'] = dashboard_data[litter_columns].sum().to_dict()
        
#         # Correlation Coefficient
#         correlation_mapping = {
#             "Population Density": "Population_Density",
#             "Education amenities density": "education_density",
#             "Entertainment amenities density": "entertainment_density",
#             "Food amenities density": "Food_density",
#             "Leisure amenities density": "leisure_density",
#             "Shopping amenities density": "shopping_density"
#         }
        
#         if y_axis in correlation_mapping:
#             selected_column = correlation_mapping[y_axis]
#             correlation_value = correlation_data.loc[correlation_data['Parameter Name'] == selected_column, 'Correlation Coefficient'].values
#             response_data['correlation_coefficient'] = correlation_value[0] if len(correlation_value) > 0 else None
        
#         # GPS Data (lat, lon, quantity, year)
#         response_data['gps_data'] = gps_data[['Latitude', 'Longitude', 'All Item Type', 'Date and Time:']].to_dict(orient='records')


        
#         return func.HttpResponse(json2.dumps(response_data), mimetype="application/json")
#     except Exception as e:
#         logging.error(f"Error processing request: {str(e)}")
#         return func.HttpResponse(f"Internal Server Error: {str(e)}", status_code=500)

