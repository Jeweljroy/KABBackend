
import azure.functions as func
import json
import logging
import io
import geopandas as gpd
from azure.storage.blob import BlobServiceClient

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
BLOB_NAME = "Amenity_PredictionScreen.geojson"

def fetch_geojson_from_blob():
    try:
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=BLOB_NAME)
        blob_data = blob_client.download_blob().readall()
        gdf = gpd.read_file(io.BytesIO(blob_data))

        # Drop rows with any null values
        gdf = gdf.dropna()

        # Ensure expected columns are string for consistent filtering
        for col in ['State', 'County', 'TRACTID']:
            gdf[col] = gdf[col].astype(str)

        return gdf
    except Exception as e:
        logging.error(f"Error fetching GeoJSON: {e}")
        return None

@bp.function_name('PredictionAmenitiesBased')
@bp.route(route="amenitiesBasedPrediction", methods=["GET"])
def amenitiesBasedPrediction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("amenitiesBasedPrediction endpoint called")

    gdf = fetch_geojson_from_blob()

    if gdf is None:
        return func.HttpResponse("Error fetching data", status_code=500)

    # Get query parameters
    state_filter = req.params.get("State")
    county_filter = req.params.get("County")
    tractid_filter = req.params.get("TRACTID")
    week_id_filter = req.params.get("week_id")

    logging.info(f"Filters received — State: {state_filter}, County: {county_filter}, TRACTID: {tractid_filter}, week_id: {week_id_filter}")

    # Apply filters (case-insensitive, space-tolerant)
    if state_filter:
        gdf = gdf[gdf['State'].str.strip().str.lower() == state_filter.strip().lower()]
    if county_filter:
        gdf = gdf[gdf['County'].str.strip().str.lower() == county_filter.strip().lower()]
    if tractid_filter:
        gdf = gdf[gdf['TRACTID'].str.strip() == tractid_filter.strip()]
    if week_id_filter:
        try:
            gdf = gdf[gdf['week_id'] == int(week_id_filter)]
        except ValueError:
            return func.HttpResponse("Invalid week_id filter", status_code=400)

    logging.info(f"Filtered data size: {len(gdf)} rows")

    # Prepare response data
    amenities_data = []
    for _, row in gdf.iterrows():
        amenities_data.append({
            "latitude": row["latitude"],
            "longitude": row["longitude"],
            "type": row["type"]
        })

    return func.HttpResponse(json.dumps(amenities_data), mimetype="application/json")
