import azure.functions as func 
import json2
import pandas as pd
import io
from azure.storage.blob import BlobServiceClient
import logging

bp = func.Blueprint()
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

def fetch_blob_data(blob_name, file_type="csv"):
    """Fetches a file from Azure Blob Storage and returns a Pandas DataFrame."""
    blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
    blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
    download_stream = blob_client.download_blob().readall()
    
    if file_type == "csv":
        df = pd.read_csv(io.BytesIO(download_stream))
    elif file_type == "excel":
        df = pd.read_excel(io.BytesIO(download_stream), engine='openpyxl')
    else:
        raise ValueError("Unsupported file type")
    
    return df

@bp.function_name('AnalyticsAndMapKABFunction')
@bp.route(route="analytics-mapkab", methods=["GET"])
def analytics_and_mapkab(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request")

    try:
        state_filter = req.params.get("state")
        county_filter = req.params.get("county")
        tractid_filter = req.params.get("tractid")

        litter_df = fetch_blob_data("KAB_dashboard_data.csv")
        gps_df = fetch_blob_data("KAB_GPS_data.csv")
        correlation_df = fetch_blob_data("Correlation data.xlsx", file_type="excel")
        centroids_df = fetch_blob_data("USA_Centroids.csv")
        
        litter_df.columns = litter_df.columns.str.strip()
        gps_df.columns = gps_df.columns.str.strip()
        correlation_df.columns = correlation_df.columns.str.strip()
        centroids_df.columns = centroids_df.columns.str.strip()

        top_3_states = (
            litter_df.groupby("State").agg({"Estimated": "sum", "Litter density": "mean"})
            .reset_index()
            .nlargest(3, "Estimated")
        )

        top_3_states["Estimated"] = top_3_states["Estimated"].apply(lambda x: f"{x/1_000_000:.2f}M" if x >= 10_000_000 else int(x))
        top_3_states = top_3_states.to_dict(orient="records")

        if state_filter:
            litter_df = litter_df[litter_df["State"] == state_filter]
            gps_df = gps_df[gps_df["State"] == state_filter] if "State" in gps_df.columns else gps_df
            centroids_df = centroids_df[centroids_df["State"] == state_filter]

        if county_filter:
            centroids_df = centroids_df[centroids_df["County"] == county_filter]

        if tractid_filter and "TractID" in centroids_df.columns:
            centroids_df = centroids_df[centroids_df["TractID"] == int(tractid_filter)]

        centroid = [centroids_df["Latitude"].mean(), centroids_df["Longitude"].mean()] if not centroids_df.empty else None
        
        total_estimated_litter = litter_df["Estimated"].sum()
        total_estimated_litter = f"{total_estimated_litter/1_000_000:.2f}M" if total_estimated_litter >= 10_000_000 else int(total_estimated_litter)
        
        estimated_litter_density = litter_df["Litter density"].mean() if not litter_df.empty else 0

        litter_categories = ["Cigarette Butts", "Glass", "Metal", "Organic", "Other", "Paper", "Plastic", "Rubber"]
        litter_pie_chart = {category: int(litter_df[category].sum()) if category in litter_df.columns else 0 for category in litter_categories}

        # litter_categories = ["Cigarette Butts", "Glass", "Metal", "Organic", "Other", "Paper", "Plastic", "Rubber"]

        # litter_pie_chart = {
        #     category: (
        #         f"{litter_df[category].sum() / 1_000_000:.2f}M" if litter_df[category].sum() >= 10_000_000 
        #         else int(litter_df[category].sum())
        #     ) if category in litter_df.columns else 0
        #     for category in litter_categories
        # }

        
        correlation_df = correlation_df.set_index("Parameter Name")
        all_correlation_coefficients = correlation_df["Correlation Coefficient"].round(6).to_dict()
        
        correlation_analysis_data = {}
        for key, mapped_key in {
            "Population_Density": "Population_Density",
            "Education amenities_density": "education_density",
            "Entertainment amenities_density": "entertainment_density",
            "Food amenities_density": "Food_density",
            "Leisure amenities_density": "leisure_density",
            "Shopping amenities_density": "shopping_density",
            "bins_density": "bins_density",
            "Traffic density": "Traffic (vehicle milesx10^6)"
        }.items():
            correlation_coefficient = all_correlation_coefficients.get(mapped_key, 0)
            scatter_plot_data = (
                litter_df[["Litter density", mapped_key]].dropna().round(2).to_dict(orient="records")
                if mapped_key in litter_df.columns else []
            )
            correlation_analysis_data[key] = {
                "correlation_coefficient": correlation_coefficient,
                "scatter_plot": scatter_plot_data,
                "measurement_unit": "Vehicle miles / Sq. miles" if key == "Traffic density" else "# / Sq. miles"
            }

        gps_columns = ["Latitude", "Longitude", "All Item Type", "Date and Time:", "City", "Site Area:", "Site Type:", "Roadway Type:", "Survey Type:"]
        gps_data = (
            gps_df[gps_columns].rename(columns={
                "All Item Type": "Litter Quantity",
                "Site Area:": "Site Area",
                "Site Type:": "Site Type",
                "Roadway Type:": "Roadway Type",
                "Survey Type:": "Survey Type"
            }).to_dict(orient="records") if all(col in gps_df.columns for col in gps_columns) else []
        )
        
        response_data = {
            "top_3_states": top_3_states,
            "total_estimated_litter": total_estimated_litter,
            "estimated_litter_density": estimated_litter_density,
            "all_correlation_coefficients": all_correlation_coefficients,
            "litter_pie_chart": litter_pie_chart,
            "correlation_analysis": correlation_analysis_data,
            "gps_data": gps_data,
            "centroid": centroid
        }
        
        return func.HttpResponse(json2.dumps(response_data, indent=4), mimetype="application/json")
    
    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)