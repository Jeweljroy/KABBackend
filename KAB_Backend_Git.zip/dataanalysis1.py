import azure.functions as func
import pandas as pd
import io
import json
import os
import logging
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")


# # # Create a Blueprint for organizing functions
bp = func.Blueprint()

# Azure Blob Storage connection details
# BLOB_CONNECTION_STRING = os.getenv("AzureWebJobsStorage")

BLOB_NAME_1 = "Analysis_data_final.csv"
BLOB_NAME_2 = "CleanSwell_anlysis.csv"

# Initialize Blob Service Client globally for efficiency
blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)

def get_blob_data(blob_name):
    try:
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        
        if not blob_data:
            raise ValueError(f"Blob {blob_name} is empty")

        return blob_data.decode('utf-8', errors='replace')  # Replace invalid characters
    except UnicodeDecodeError:
        raise ValueError(f"Blob {blob_name} contains invalid characters or incorrect encoding. Expected UTF-8.")
    except Exception as e:
        raise ValueError(f"Error accessing blob {blob_name}: {str(e)}")


def process_csv(blob_data):
    try:
        data = io.StringIO(blob_data)
        df = pd.read_csv(data)
        
        if df.empty:
            raise ValueError("CSV file is empty or improperly formatted.")
        
        return df
    except pd.errors.ParserError:
        raise ValueError("CSV file could not be parsed properly. Ensure it is a valid CSV format.")
    except Exception as e:
        raise ValueError(f"Error processing CSV: {str(e)}")


def merge_data(df1, df2):
    required_columns = {'GEOID', 'Year', 'State', 'County', 'STATEID', 'COUNTYID', 'TRACTID'}
    
    missing_columns_df1 = required_columns - set(df1.columns)
    missing_columns_df2 = required_columns - set(df2.columns)

    if missing_columns_df1:
        raise ValueError(f"Missing columns in Analysis_data_final.csv: {missing_columns_df1}")
    if missing_columns_df2:
        raise ValueError(f"Missing columns in CleanSwell_analysis.csv: {missing_columns_df2}")
    
    return pd.merge(df1, df2, on=list(required_columns), how='inner')

def filter_data(df, state=None, county=None, year=None, tract_id=None):
    if state and "State" in df.columns:
        df = df[df['State'] == state]
    if county and "County" in df.columns:
        df = df[df['County'] == county]
    if year and "Year" in df.columns:
        df = df[df['Year'] == int(year)]
    if tract_id and "TRACTID" in df.columns:
        df = df[df['TRACTID'] == int(tract_id)]
    return df

def generate_trend_chart(df):
    if 'Cleanups' not in df.columns:
        logging.warning("Missing 'Cleanups' column in dataset")
        return {}
    return df.groupby('Year')['Cleanups'].sum().to_dict()

def get_total_cleanups(df):
    if 'Cleanups' not in df.columns:
        logging.warning("Missing 'Cleanups' column in dataset")
        return 0
    return int(df['Cleanups'].sum())

def get_top_states(df):
    if 'Cleanups' not in df.columns or 'State' not in df.columns:
        logging.warning("Missing 'Cleanups' or 'State' column in dataset")
        return {}
    return df.groupby('State')['Cleanups'].sum().nlargest(3).to_dict()

def get_top_counties(df):
    if 'Cleanups' not in df.columns or 'County' not in df.columns:
        logging.warning("Missing 'Cleanups' or 'County' column in dataset")
        return {}
    return df.groupby('County')['Cleanups'].sum().nlargest(3).to_dict()

def generate_pie_chart(df):
    litter_categories = ['Cigarette', 'Glass', 'Metal', 'Organic', 'Other', 'Paper', 'Plastic', 'Rubber']
    available_categories = [col for col in litter_categories if col in df.columns]
    
    if not available_categories:
        logging.warning("None of the expected litter category columns are present in dataset")
        return {}

    return df[available_categories].sum().to_dict()

def get_map_view(df):
    required_columns = {'Latitude', 'Longitude', 'Litter Quantity', 'Year'}
    
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        logging.warning(f"Missing columns for map view: {missing_columns}")
        return []
    
    return df[list(required_columns)].to_dict(orient='records')

app = func.FunctionApp()

@app.route(route="read_blob_data", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Fetch data from Azure Blob Storage
        blob_data_1 = get_blob_data(BLOB_NAME_1)
        blob_data_2 = get_blob_data(BLOB_NAME_2)

        # Process CSV data
        df1 = process_csv(blob_data_1, BLOB_NAME_1)
        df2 = process_csv(blob_data_2, BLOB_NAME_2)
        
        # Merge datasets
        df = merge_data(df1, df2)

        # Get filters from query parameters
        state = req.params.get('state')
        county = req.params.get('county')
        year = req.params.get('year')
        tract_id = req.params.get('tract_id')

        # Apply filters
        df = filter_data(df, state, county, year, tract_id)

        # Generate insights
        result = {
            "trend_chart": generate_trend_chart(df),
            "total_cleanups": get_total_cleanups(df),
            "top_states": get_top_states(df),
            "top_counties": get_top_counties(df),
            "pie_chart": generate_pie_chart(df),
            "map_view": get_map_view(df)
        }

        return func.HttpResponse(json.dumps(result), mimetype="application/json")
    
    except ValueError as ve:
        logging.error(f"Value Error: {str(ve)}")
        return func.HttpResponse(json.dumps({"error": str(ve)}), status_code=400, mimetype="application/json")
    
    except Exception as e:
        logging.exception(f"Unexpected Error: {str(e)}")
        return func.HttpResponse(json.dumps({"error": "An unexpected error occurred"}), status_code=500, mimetype="application/json")