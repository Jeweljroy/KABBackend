import azure.functions as func
import logging
import csv
import json
from azure.storage.blob import BlobServiceClient
import os

# Initialize Blueprint
bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
KAB_DASHBOARD_FILE = "KAB_dashboard_data.csv"
# CORRELATION_FILE = "Correlation data.csv"


def get_blob_data(file_name):
    """Fetch CSV file content from Azure Blob Storage"""
    blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
    blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)
    blob_data = blob_client.download_blob().content_as_text()
    return blob_data

@bp.function_name('KABDropdownFunction')
@bp.route(route="kabdropdowns", methods=["GET"])
def KABDropdownFunction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Fetching dropdown data from KAB_dashboard_data.csv and Correlation data.csv")
    
    try:
        # Fetch and process states from KAB_dashboard_data.csv
        kab_data = get_blob_data(KAB_DASHBOARD_FILE)
        states = set()
        csv_reader = csv.DictReader(kab_data.splitlines())
        for row in csv_reader:
            if row.get("State"):
                states.add(row["State"].strip())
        
        states_list = [{"value": "All States", "label": "All States"}] + \
                      sorted([{"value": state, "label": state} for state in states], key=lambda x: x["value"])
        
        # Fetch and process parameter names from Correlation data.csv
        # correlation_data = get_blob_data(CORRELATION_FILE)
        parameters = [
            {"value": "Population_Density", "label": "Population Density"},
            {"value": "Education amenities_density", "label": "Education Amenities Density"},
            {"value": "Entertainment amenities_density", "label": "Entertainment Amenities Density"},
            {"value": "Food amenities_density", "label": "Food Amenities Density"},
            {"value": "Leisure amenities_density", "label": "Leisure Amenities Density"},
            {"value": "Shopping amenities_density", "label": "Shopping Amenities Density"},
            {"value": "bins_density", "label": "Bins Density"},
            {"value": "Traffic density", "label": "Traffic Density"}
        ]

        response_data = {
            "States": states_list,
            "Parameter Name": parameters
        }
        return func.HttpResponse(json.dumps(response_data), mimetype="application/json", status_code=200)
    
    except Exception as e:
        logging.error(f"Error fetching dropdown data: {str(e)}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
