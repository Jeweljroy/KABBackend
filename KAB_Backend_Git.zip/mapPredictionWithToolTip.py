
import azure.functions as func
import pandas as pd
import logging
import tempfile
import os
from azure.storage.blob import BlobServiceClient
from datetime import datetime
import json
from typing import Union

bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

# Caching
DF_CACHE = {}
BLOB_MODIFIED_CACHE = {}

COLOR_LABELS = ["#008000", "#80FF00", "#FFFF00", "#FF8000", "#FF0000"]

def get_blob_df(week_id: str) -> Union[pd.DataFrame, None]:
    try:
        filename = f"Prediction_Output_wk{week_id}.csv"
        blob_service = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service.get_blob_client(CONTAINER_NAME, filename)

        props = blob_client.get_blob_properties()
        if week_id in DF_CACHE and BLOB_MODIFIED_CACHE.get(week_id) == props.last_modified:
            logging.info(f"Using cached DataFrame for week {week_id}")
            return DF_CACHE[week_id]

        # Download blob
        temp_path = os.path.join(tempfile.gettempdir(), filename)
        with open(temp_path, "wb") as f:
            f.write(blob_client.download_blob().readall())
        logging.info(f"Downloaded and saved blob to {temp_path}")

        df = pd.read_csv(temp_path)

        # Convert numeric columns
        for col in [
            "Litter_density", "Predicted_Qty",
            "cigarette_score", "glass_score", "metal_score", "organic_score",
            "other_score", "paper_score", "plastic_score", "rubber_score"
        ]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

        # Add colorType
        if "Litter_density" in df.columns:
            color_bins = pd.qcut(df["Litter_density"], q=5, duplicates="drop", retbins=True)[1]
            df["colorType"] = pd.cut(
                df["Litter_density"],
                bins=color_bins,
                labels=COLOR_LABELS[:len(color_bins) - 1],
                include_lowest=True
            ).astype(str)

        # Cache result
        DF_CACHE[week_id] = df
        BLOB_MODIFIED_CACHE[week_id] = props.last_modified
        return df

    except Exception as e:
        logging.error(f"Error loading blob for week {week_id}: {e}")
        return None

@bp.route(route="mapPredictionWithToolTip", methods=["GET"])
def mapPredictionWithToolTip(req: func.HttpRequest) -> func.HttpResponse:
    try:
        week_id = req.params.get("week_id") or str(datetime.today().isocalendar().week)
        logging.info(f"Fetching prediction data for week_id: {week_id}")
        df = get_blob_df(week_id)

        if df is None or df.empty:
            return func.HttpResponse(json.dumps({"data": [], "centroid": None}), status_code=200)

        # Apply filters
        filters = {
            "State": req.params.get("State"),
            "County": req.params.get("County"),  # 'County' maps to 'City' in the data
            "TRACTID": req.params.get("TRACTID"),
            "colorType": req.params.get("colorType"),
        }

        logging.info(f"Applying filters: {filters}")

        for col, val in filters.items():
            if val:
                val = val.strip()
                if col == "County":  # Map 'County' param to 'City' column in data
                    if "City" in df.columns:
                        df = df[df["City"].astype(str).str.strip().str.lower() == val.lower()]
                elif col in df.columns:
                    if col == "colorType":
                        val = val.upper()
                        val = f"#{val}" if not val.startswith("#") else val
                    df = df[df[col].astype(str).str.strip().str.lower() == val.lower()]

        if df.empty:
            logging.warning("No data after filtering.")
            return func.HttpResponse(json.dumps({"data": [], "centroid": None}), status_code=200)

        # Compute centroid
        centroid = [df["latitude"].mean(), df["longitude"].mean()] if "latitude" in df.columns and "longitude" in df.columns else None

        # Prepare pie chart mapping
        category_mapping = {
            "Cigarette": "cigarette_score",
            "Glass": "glass_score",
            "Metal": "metal_score",
            "Organic": "organic_score",
            "Other": "other_score",
            "Paper": "paper_score",
            "Plastic": "plastic_score",
            "Rubber": "rubber_score"
        }

        records = []
        for _, row in df.iterrows():
            pie = {k: round(row.get(v, 0), 2) for k, v in category_mapping.items()}
            records.append({
                "GEOID": row.get("GEOID"),
                "State": row.get("State"),
                "County": row.get("City"),  # Use City for County
                "TRACTID": row.get("TRACTID"),
                "Litter_density": round(row.get("Litter_density", 0), 2),
                "Predicted_Qty": round(row.get("Predicted_Qty", 0), 2),
                "latitude": row.get("latitude"),
                "longitude": row.get("longitude"),
                "colorType": row.get("colorType"),
                "pie_chart": pie
            })

        return func.HttpResponse(
            json.dumps({"data": records, "centroid": centroid}),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        logging.error(f"Exception in mapPredictionWithToolTip: {e}")
        return func.HttpResponse(json.dumps({"error": str(e)}), status_code=500)
