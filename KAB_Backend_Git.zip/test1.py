import json

# Path to your GeoJSON file
geojson_file = 'Prediction_Output 1.geojson'

# Load GeoJSON data
with open(geojson_file, 'r') as f:
    data = json.load(f)

# Count features where State is California
california_count = sum(
    1 for feature in data['features']
    if feature.get('properties', {}).get('State') == 'California'
)

print(f"Total California features: {california_count}")

