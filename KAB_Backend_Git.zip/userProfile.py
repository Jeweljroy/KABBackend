import logging
import azure.functions as func
from azure.data.tables import TableServiceClient
import json2
import os
from azure.core.exceptions import ResourceNotFoundError


from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Environment Variables
SECRET_KEY = os.getenv("SECRET_KEY")
STORAGE_CONNECTION_STRING = os.getenv("STORAGE_CONNECTION_STRING")

bp = func.Blueprint()

def get_table_client():
    """Returns the Azure Table client."""
    try:
        print("Connecting to Azure Table Storage...")
        table_service_client = TableServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
        table_client = table_service_client.get_table_client(TABLE_NAME)
        print(f"Connected to table: {TABLE_NAME}")
        return table_client
    except Exception as e:
        logging.error(f"Failed to connect to Azure Table Storage: {str(e)}")
        print(f"Error: {str(e)}")
        return None

@bp.function_name("view_profile")
@bp.route(route="view_profile", methods=["POST"])
def view_profile(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Fetching user profile details from Azure Table Storage.")

    try:
        req_body = req.get_json()
        email = req_body.get("email")

        if not email:
            return func.HttpResponse(
                json2.dumps({"error": "Email parameter is required"}),
                status_code=400,
                mimetype="application/json"
            )

        table_client = get_table_client()
        if not table_client:
            return func.HttpResponse(
                json2.dumps({"error": "Failed to connect to database"}),
                status_code=500,
                mimetype="application/json"
            )

        # ✅ Use query_entities to include system fields like Timestamp
        filter_query = f"PartitionKey eq 'User' and RowKey eq '{email}'"
        entities = list(table_client.query_entities(filter_query))


        if not entities:
            logging.warning(f"User not found: {email}")
            return func.HttpResponse(
                json2.dumps({"error": "User not found"}),
                status_code=404,
                mimetype="application/json"
            )

        entity = entities[0]
        logging.info(f"Fetched entity: {entity}")

        # ✅ Extract custom timestampCreated field instead of system Timestamp
        timestamp_value = str(entity.get("timestampCreated", ""))

        user_data = {
            "email": entity.get("RowKey", ""),
            "state": entity.get("state", ""),
            "username": entity.get("username", ""),
            "fullOption": entity.get("fullOption", ""),
            "is_verified": str(entity.get("is_verified", "")).lower(),
            "organization": entity.get("organization", ""),
            "role": entity.get("role", ""),
            "target": entity.get("target", ""),
            "timestamp": timestamp_value
        }

        return func.HttpResponse(json2.dumps(user_data), status_code=200, mimetype="application/json")

    except Exception as e:
        logging.error(f"Error fetching user data: {str(e)}")
        return func.HttpResponse(
            json2.dumps({"error": "Internal Server Error"}),
            status_code=500,
            mimetype="application/json"
        )

from azure.data.tables import UpdateMode

@bp.function_name("edit_profile")
@bp.route(route="edit_profile", methods=["POST"])
def edit_profile(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing edit_profile request.")

    try:
        req_body = req.get_json()
        email = req_body.get("email")
        state = req_body.get("state")
        username = req_body.get("username")
        fullOption = req_body.get("fullOption")
        is_verified = req_body.get("is_verified")
        organization = req_body.get("organization")
        role = req_body.get("role")
        target = req_body.get("target")

        if not email:
            return func.HttpResponse('{"error": "Missing \'email\' field"}', status_code=400, mimetype="application/json")

        table_client = get_table_client()
        if not table_client:
            return func.HttpResponse('{"error": "Failed to connect to database"}', status_code=500, mimetype="application/json")

        partition_key = "User"
        row_key = email

        # ✅ Retrieve existing entity
        try:
            entity = table_client.get_entity(partition_key=partition_key, row_key=row_key)
        except Exception:
            logging.error(f"User profile not found for {email}")
            return func.HttpResponse('{"error": "User profile not found"}', status_code=404, mimetype="application/json")

        # ✅ Update only provided fields
        if state is not None:
            entity["state"] = state
        if username is not None:
            entity["username"] = username
        if fullOption is not None:
            entity["fullOption"] = fullOption
        if is_verified is not None:
            entity["is_verified"] = str(is_verified).lower() == "true"
        if organization is not None:
            entity["organization"] = organization
        if role is not None:
            entity["role"] = role
        if target is not None:
            entity["target"] = target

        # ✅ Save the updated entity
        table_client.update_entity(entity=entity, mode=UpdateMode.REPLACE)
        logging.info(f"Profile updated successfully for {email}")

        return func.HttpResponse('{"message": "Profile updated successfully"}', status_code=200, mimetype="application/json")

    except Exception as e:
        logging.error(f"Error editing profile: {str(e)}")
        return func.HttpResponse(f'{{"error": "Profile update failed: {str(e)}"}}', status_code=500, mimetype="application/json")
