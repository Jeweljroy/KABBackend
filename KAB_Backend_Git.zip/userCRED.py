#

import azure.functions as func
import json2
import time
import bcrypt
import pyotp
import jwt as pyjwt
import smtplib
from email.mime.text import MIMEText
from itsdangerous import URLSafeTimedSerializer
from azure.data.tables import TableServiceClient
import os
import logging
from datetime import datetime


bp = func.Blueprint()

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Environment Variables
SECRET_KEY = os.getenv("SECRET_KEY")
STORAGE_CONNECTION_STRING = os.getenv("STORAGE_CONNECTION_STRING")



EMAIL_USERNAME = os.getenv("EMAIL_USERNAME")
EMAIL_PASSWORD =  os.getenv("EMAIL_PASSWORD")

# Azure Table Storage Setup
TABLE_NAME = os.getenv("TABLE_NAME")
table_service_client = TableServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
table_client = table_service_client.get_table_client(TABLE_NAME)

# OTP Store (temporary)
otp_store = {}

# Serializer for Token Handling
serializer = URLSafeTimedSerializer(SECRET_KEY)

# Helper Functions
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(plain_password, hashed_password):
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def send_email(to_email, subject, body):
    try:
        msg = MIMEText(body, "html")
        msg["Subject"] = subject
        msg["From"] = EMAIL_USERNAME
        msg["To"] = to_email

        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(EMAIL_USERNAME, EMAIL_PASSWORD)
            server.sendmail(EMAIL_USERNAME, to_email, msg.as_string())
    except Exception as e:
        print(f"Email sending error: {str(e)}")

#changed the code for @kab.org verification
@bp.function_name('register_user')
@bp.route(route="register_user", methods=["POST"])
def register_user(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        email = data.get('email', '').strip()
        password = data.get('password', '').strip()
        username = data.get('username', '').strip()
        state = data.get('state', 'California')
        organization = data.get('organization', '')
        role = data.get('role', '')
        target = data.get('target', '')

        if not email or not password or not username:
            return func.HttpResponse(json2.dumps({"msg": "Email, password, and username required"}), status_code=400)

        # Check if user exists
        try:
            table_client.get_entity(partition_key="User", row_key=email)
            return func.HttpResponse(json2.dumps({"msg": "User already exists"}), status_code=409)
        except:
            pass  # Safe to continue

        hashed_pw = hash_password(password)
        otp_secret = pyotp.random_base32()

        user_entity = {
            "PartitionKey": "User",
            "RowKey": email,
            "username": username,
            "password": hashed_pw,
            "is_verified": "false",
            "otp_secret": otp_secret,
            "state": state,
            "fullOption": "0",
            "organization": organization,
            "role": role,
            "target": target,
            "timestampCreated": datetime.utcnow().isoformat()
        }

        table_client.create_entity(user_entity)

        # Only send verification link if email domain is kab.org
        if email.lower().endswith('@kab.org'):
            token = serializer.dumps(email, salt='email-verify')
            link = f"https://lees1ddoaifunc02.azurewebsites.net/api/verify_email_user/{token}?code=Zzbky-_K_zZ3muIHEy8qkEuqiI5PTrL69RSTUbAlfOFnAzFuL71U8w=="
            send_email(email, "Verify Your Email", f"<p>Click to verify: <a href='{link}'>{link}</a></p>")

        return func.HttpResponse(json2.dumps({"msg": "User registered. Verify email if eligible."}), status_code=201)

    except Exception as e:
        logging.exception("Registration failed")
        return func.HttpResponse(json2.dumps({"msg": str(e)}), status_code=500)



# Email Verification
@bp.function_name('verify_email_user')
@bp.route(route="verify_email_user/{token}", methods=["GET"])
def verify_email_user(req: func.HttpRequest) -> func.HttpResponse:
    token = req.route_params.get('token')
    try:
        email = serializer.loads(token, salt='email-verify', max_age=3600)
        entity = table_client.get_entity("User", email)
        entity["is_verified"] = "true"
        table_client.update_entity(entity)
        return func.HttpResponse(json2.dumps({"msg": "Email verified successfully"}), status_code=200)
    except:
        return func.HttpResponse(json2.dumps({"msg": "Invalid or expired token"}), status_code=400)

def verify_passwords(input_password, stored_password):
    logging.info(f"Checking password. Input: {input_password}, Stored: {stored_password}")
    return bcrypt.checkpw(input_password.encode(), stored_password.encode())

connection_string = os.getenv("AzureWebJobsStorage")
service_client = TableServiceClient.from_connection_string(conn_str=connection_string)
table_client = service_client.get_table_client("UsersData")

@bp.function_name('login_user')
@bp.route(route="login_user", methods=["POST"])
def login_user(req: func.HttpRequest) -> func.HttpResponse:
    from datetime import datetime

    try:
        data = req.get_json()
        email, password = data.get('email'), data.get('password')

        if not email or not password:
            return func.HttpResponse(
                json2.dumps({"msg": "Email and password required"}),
                status_code=400
            )

        try:
            entity = table_client.get_entity(partition_key="User", row_key=email)
        except:
            return func.HttpResponse(
                json2.dumps({"msg": "User not found"}),
                status_code=404
            )

        if not verify_password(password, entity["password"]):
            return func.HttpResponse(
                json2.dumps({"msg": "Invalid credentials"}),
                status_code=401
            )

        if entity.get("is_verified") != "true":
            return func.HttpResponse(
                json2.dumps({"msg": "Verify email first"}),
                status_code=403
            )

        # Update timestampCreated field with current login time
        entity["timestampCreated"] = datetime.utcnow().isoformat()

        # Prepare the entity for upsert
        entity_update = {
            "PartitionKey": entity["PartitionKey"],
            "RowKey": entity["RowKey"],
            "timestampCreated": entity["timestampCreated"],
            "email": entity["RowKey"],  # Ensure email is preserved
            "state": entity.get("state", ""),
            "username": entity.get("username", ""),
            "fullOption": entity.get("fullOption", ""),
            "is_verified": entity.get("is_verified", ""),
            "organization": entity.get("organization", ""),
            "role": entity.get("role", ""),
            "target": entity.get("target", "")
        }

        # Use upsert_entity to insert or update the entity
        table_client.upsert_entity(entity_update)

        # Generate JWT token
        token = pyjwt.encode({"email": email}, SECRET_KEY, algorithm="HS256")
        state_info = "All states" if entity.get("fullOption") == "1" else entity.get("state", "")

        return func.HttpResponse(
            json2.dumps({
                "token": token,
                "state": state_info,
                "email": email,
                "username": entity.get("username", "")
            }),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Login error: {e}")
        return func.HttpResponse(
            json2.dumps({"msg": "Internal server error"}),
            status_code=500
        )



# Request Password Reset OTP
@bp.function_name('request_reset_otp_user')
@bp.route(route="request_reset_otp_user", methods=["POST"])
def request_reset_otp_user(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        email = data.get('email')

        entity = table_client.get_entity("User", email)
        otp = pyotp.TOTP(entity["otp_secret"]).now()[:6]

        otp_store[email] = {"otp": otp, "expires_at": time.time() + 600}

        send_email(email, "Password Reset OTP", f"Your OTP: {otp} (valid for 10 minutes)")

        return func.HttpResponse(json2.dumps({"msg": "OTP sent to email"}), status_code=200)
    except:
        return func.HttpResponse(json2.dumps({"msg": "User not found"}), status_code=404)

# Reset Password
@bp.function_name('reset_password_user')
@bp.route(route="reset_password_user", methods=["POST"])
def reset_password_user(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        email, otp, new_password = data.get('email'), data.get('otp'), data.get('newPassword')

        if email not in otp_store or time.time() > otp_store[email]['expires_at']:
            return func.HttpResponse(json2.dumps({"msg": "OTP expired or invalid"}), status_code=400)

        if otp != otp_store[email]['otp']:
            return func.HttpResponse(json2.dumps({"msg": "Incorrect OTP"}), status_code=400)

        entity = table_client.get_entity("User", email)
        entity["password"] = hash_password(new_password)
        table_client.update_entity(entity)

        del otp_store[email]

        return func.HttpResponse(json2.dumps({"msg": "Password reset successful"}), status_code=200)
    except:
        return func.HttpResponse(json2.dumps({"msg": "User not found"}), status_code=404)
    
from azure.core.exceptions import ResourceNotFoundError

@bp.function_name('delete_user')
@bp.route(route="delete_user", methods=["POST"])
def delete_user(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        email = data.get("email")

        if not email:
            return func.HttpResponse(json2.dumps({"msg": "Email is required"}), status_code=400)

        email = email.lower().strip()  # Normalize email

        try:
            entity = table_client.get_entity(partition_key="User", row_key=email)
            table_client.delete_entity(partition_key="User", row_key=email)
            return func.HttpResponse(json2.dumps({"msg": "User deleted successfully"}), status_code=200)
        except ResourceNotFoundError:
            return func.HttpResponse(json2.dumps({"msg": "User not found"}), status_code=404)

    except Exception as e:
        return func.HttpResponse(json2.dumps({"msg": f"Error: {str(e)}"}), status_code=500)
