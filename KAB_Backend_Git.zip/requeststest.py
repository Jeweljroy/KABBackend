import requests
import time

url = "https://archive-api.open-meteo.com/v1/archive"
params = {
    "latitude": 39.023828,
    "longitude": -95.738057,
    "start_date": "2020-09-25",
    "end_date": "2020-09-25",
    "hourly": ["cloudcover", "temperature_2m"],
    "daily": ["temperature_2m_max", "temperature_2m_min"],
    "timezone": "auto"
}

def fetch_weather():
    for attempt in range(5):  # Retry up to 5 times
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()  # Raise error for bad response
            return response.json()
        except requests.RequestException as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            time.sleep(2 ** attempt)  # Exponential backoff (2, 4, 8 sec)
    return None  # Return None if all retries fail

data = fetch_weather()
if data:
    print("Success:", data)
else:
    print("API request failed after retries.")
