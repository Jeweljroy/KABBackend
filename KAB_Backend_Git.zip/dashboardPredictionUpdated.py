import azure.functions as func
import pandas as pd
import geopandas as gpd
import logging
import tempfile
import os
import json
from shapely.geometry import Point
from datetime import datetime
from azure.storage.blob import BlobServiceClient
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Constants
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
CHUNK_SIZE = 16 * 1024 * 1024  # 16 MB
MAX_WORKERS = 8

bp = func.Blueprint()

def format_large_number(value):
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f} M"
    return round(value, 2)

def download_chunk(blob_client, start, end, index):
    stream = blob_client.download_blob(offset=start, length=end - start + 1)
    return index, stream.readall()

def download_blob_in_chunks(blob_client, local_path):
    blob_size = blob_client.get_blob_properties().size
    chunks = [(i, min(i + CHUNK_SIZE, blob_size) - 1, idx) 
              for idx, i in enumerate(range(0, blob_size, CHUNK_SIZE))]

    results = [None] * len(chunks)
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(download_chunk, blob_client, start, end, idx): idx
            for start, end, idx in chunks
        }
        for future in as_completed(futures):
            idx, data = future.result()
            results[idx] = data

    with open(local_path, 'wb') as f:
        for chunk in results:
            f.write(chunk)

@bp.function_name("dashboardPredictionUpdated")
@bp.route(route="dashboardPredictionUpdated", methods=["GET"])
def dashboard_prediction_updated(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Extract query parameters
        state_filter = req.params.get("State")
        county_filter = req.params.get("County")  # Still using 'County' as request param
        tract_filter = req.params.get("TRACTID")
        week_id_param = req.params.get("week_id")

        # Determine the week_id to use
        if not week_id_param or not week_id_param.isdigit():
            week_id = datetime.utcnow().isocalendar().week
            logging.info(f"No valid 'week_id' provided. Using current week number: {week_id}")
        else:
            week_id = int(week_id_param)

        blob_name = f"Prediction_Output_wk{week_id}.csv"

        # Download the CSV file from Azure Blob Storage
        blob_service = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        blob_client = blob_service.get_blob_client(container=CONTAINER_NAME, blob=blob_name)

        local_path = os.path.join(tempfile.gettempdir(), blob_name)
        download_blob_in_chunks(blob_client, local_path)

        # Read and clean data
        df = pd.read_csv(local_path, dtype={"TRACTID": str})
        df.columns = df.columns.str.strip().str.lower()

        for col in ['state', 'city', 'tractid']:
            if col in df.columns:
                df[col] = df[col].astype(str).str.strip().str.lower()

        df.dropna(subset=["latitude", "longitude"], inplace=True)
        df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
        df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")
        df["litter_density"] = pd.to_numeric(df.get("litter_density", 0), errors="coerce").fillna(0)
        df["predicted_qty"] = pd.to_numeric(df.get("predicted_qty", 0), errors="coerce").fillna(0)

        if state_filter:
            df = df[df["state"] == state_filter.strip().lower()]
        if county_filter:
            df = df[df["city"] == county_filter.strip().lower()]
        if tract_filter:
            df = df[df["tractid"] == tract_filter.strip().lower()]

        # Compute centroid
        if not df.empty:
            gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df["longitude"], df["latitude"]), crs="EPSG:4326")
            centroid = gdf.geometry.unary_union.centroid
            centroid_lat, centroid_lon = centroid.y, centroid.x
        else:
            centroid_lat, centroid_lon = None, None

        # Aggregations
        total_litter = df["predicted_qty"].sum()
        avg_density = df["litter_density"].mean()

        pie_chart = {}
        categories = ["paper", "plastic", "cigarette", "glass", "metal", "organic", "rubber", "other"]
        for cat in categories:
            col = f"predicted_{cat}"
            pie_chart[cat.capitalize()] = round(df[col].sum(), 2) if col in df.columns else 0.0

        response = {
            "centroid": {"latitude": centroid_lat, "longitude": centroid_lon},
            "total": {
                "Total Estimated Litter": format_large_number(total_litter),
                "Estimated Litter Density": format_large_number(avg_density),
                "pie_chart": pie_chart
            }
        }

        return func.HttpResponse(json.dumps(response), mimetype="application/json", status_code=200)

    except Exception as e:
        logging.error(f"Error in dashboardPredictionUpdated: {e}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
